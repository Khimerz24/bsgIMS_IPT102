module.exports = {
	content: ["./**/*.{html,js,php}"],
	theme: {
		extend: {
			colors: {
				primary: {
					DEFAULT: "#4169e1",
					light: "#6384e6",
					dark: "#2851db",
				},
			},
		},
	},
	plugins: [],
};
