<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BSG General Store - Login</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#4169E1',
                        secondary: '#f2f5fe',
                        accent: '#2c3afb',
                    }
                }
            }
        }
    </script>
</head>
<body class="flex items-center justify-center min-h-screen bg-secondary">
    <div class="w-full max-w-md p-8 bg-white rounded-lg shadow-md">
        <div class="mb-8 text-center">
            <h1 class="text-3xl font-bold text-primary">BSG General Store</h1>
            <p class="text-gray-600">Inventory Management System</p>
        </div>
        
        <?php if(isset($login_error)): ?>
            <div class="px-4 py-3 mb-4 text-red-700 bg-red-100 border border-red-400 rounded">
                <?php echo $login_error; ?>
            </div>
        <?php endif; ?>
        
        <form action="login_process.php" method="post">
            <div class="mb-4">
                <label class="block mb-2 text-sm font-bold text-gray-700" for="username">
                    Username
                </label>
                <input class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline focus:border-primary" 
                       id="username" 
                       name="username" 
                       type="text" 
                       placeholder="Enter your username"
                       required>
            </div>
            <div class="mb-6">
                <label class="block mb-2 text-sm font-bold text-gray-700" for="password">
                    Password
                </label>
                <input class="w-full px-3 py-2 leading-tight text-gray-700 border rounded shadow appearance-none focus:outline-none focus:shadow-outline focus:border-primary" 
                       id="password" 
                       name="password" 
                       type="password" 
                       placeholder="Enter your password"
                       required>
            </div>
            <div class="flex items-center justify-center">
                <button class="w-full px-4 py-2 font-bold text-white rounded bg-primary hover:bg-accent focus:outline-none focus:shadow-outline" 
                        type="submit"
                        name="login">
                    Sign In
                </button>
            </div>
        </form>
    </div>
    <footer class="fixed w-full text-sm text-center text-gray-500 bottom-4">
        &copy; <?php echo date('Y'); ?> BSG General Store. All rights reserved.
    </footer>
</body>
</html>