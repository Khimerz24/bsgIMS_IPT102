



<?php


// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the delete logic ---
require_once 'config/database.php';

// ... (existing code for POST check and deletion) ...


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    try {
        // First check if supplier exists
        $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $supplier = $stmt->fetch();

        if (!$supplier) {
            header('Location: suppliers.php?error=supplier-not-found');
            exit();
        }

        // Delete the supplier
        $stmt = $pdo->prepare("DELETE FROM suppliers WHERE id = ?");
        $stmt->execute([$_POST['id']]);

        header('Location: suppliers.php?success=deleted');
        exit();
    } catch (PDOException $e) {
        // Check if error is due to foreign key constraint
        if ($e->getCode() == '23000') {
            header('Location: suppliers.php?error=constraint');
            exit();
        }
        header('Location: suppliers.php?error=delete-failed');
        exit();
    }
}

header('Location: suppliers.php');
exit();