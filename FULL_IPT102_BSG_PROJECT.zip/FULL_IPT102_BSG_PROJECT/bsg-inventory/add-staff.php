<?php

// --- Role Check (must occur before any output) ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Include Database Config ---
require_once 'config/database.php';

// --- Initialize variables ---
$errors = [];
$username = '';
$role = 'staff';

// --- Handle Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'staff';

    // Validation
    if (empty($username)) {
        $errors['username'] = 'Username is required.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $errors['username'] = 'Username already taken.';
        }
    }

    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Passwords do not match.';
    }

    if (!in_array($role, ['admin', 'staff'])) {
        $errors['role'] = 'Invalid role selected.';
    }

    if (empty($errors)) {
        try {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO users (username, password, role, status, created_at)
                 VALUES (?, ?, ?, 'active', NOW())"
            );
            $stmt->execute([$username, $hashed, $role]);
            header('Location: staff.php?success=added');
            exit();
        } catch (PDOException $e) {
            error_log("Error adding staff: " . $e->getMessage());
            $errors['general'] = 'Database error occurred. Could not add staff member.';
        }
    }
}

// --- Include Header After Logic ---
require_once 'includes/header.php';
?>

<div class="p-6">
  <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg">
    <div class="p-4 rounded-t-lg bg-primary-light">
      <h2 class="text-2xl font-bold text-gray-800">Add New Staff Member</h2>
    </div>

    <?php if (!empty($errors['general'])): ?>
      <div class="px-4 py-3 mb-4 text-red-700 bg-red-100 border border-red-400 rounded">
        <?= htmlspecialchars($errors['general']); ?>
      </div>
    <?php endif; ?>

    <form method="POST" action="add-staff.php" class="p-6 space-y-6 rounded-b-lg bg-gray-50">
      <div>
        <label for="username" class="block mb-1 text-lg font-semibold text-gray-900">Username <span class="text-red-500">*</span></label>
        <input id="username" type="text" name="username" value="<?= htmlspecialchars($username); ?>" placeholder="e.g., jdoe" required
               class="block w-full px-4 py-2 border-2 <?= isset($errors['username']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-lg bg-white shadow focus:ring focus:ring-primary focus:ring-opacity-50 text-lg">
        <?php if (isset($errors['username'])): ?>
          <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['username']); ?></p>
        <?php endif; ?>
      </div>

      <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div>
          <label for="password" class="block mb-1 text-lg font-semibold text-gray-900">Password <span class="text-red-500">*</span></label>
          <input id="password" type="password" name="password" placeholder="Enter password" required
                 class="block w-full px-4 py-2 border-2 <?= isset($errors['password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-lg bg-white shadow focus:ring focus:ring-primary focus:ring-opacity-50 text-lg">
          <?php if (isset($errors['password'])): ?>
            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['password']); ?></p>
          <?php endif; ?>
        </div>

        <div>
          <label for="confirm_password" class="block mb-1 text-lg font-semibold text-gray-900">Confirm Password <span class="text-red-500">*</span></label>
          <input id="confirm_password" type="password" name="confirm_password" placeholder="Repeat password" required
                 class="block w-full px-4 py-2 border-2 <?= isset($errors['confirm_password']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-lg bg-white shadow focus:ring focus:ring-primary focus:ring-opacity-50 text-lg">
          <?php if (isset($errors['confirm_password'])): ?>
            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['confirm_password']); ?></p>
          <?php endif; ?>
        </div>
      </div>

      <div>
        <label for="role" class="block mb-1 text-lg font-semibold text-gray-900">Role <span class="text-red-500">*</span></label>
        <select id="role" name="role" required
                class="block w-full px-4 py-2 border-2 <?= isset($errors['role']) ? 'border-red-500' : 'border-gray-300'; ?> rounded-lg bg-white shadow focus:ring focus:ring-primary focus:ring-opacity-50 text-lg">
          <option value="staff" <?= $role === 'staff' ? 'selected' : ''; ?>>Staff</option>
          <option value="admin" <?= $role === 'admin' ? 'selected' : ''; ?>>Admin</option>
        </select>
        <?php if (isset($errors['role'])): ?>
          <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['role']); ?></p>
        <?php endif; ?>
      </div>

      <div class="flex justify-end space-x-4">
        <a href="staff.php" class="px-6 py-3 text-lg font-medium text-center text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">Cancel</a>
        <button type="submit" class="px-6 py-3 text-lg font-semibold text-white rounded-lg bg-royal-blue hover:bg-blue-700">Add Staff Member</button>
      </div>
    </form>
  </div>
</div>

<?php require_once 'includes/footer.php'; ?>
