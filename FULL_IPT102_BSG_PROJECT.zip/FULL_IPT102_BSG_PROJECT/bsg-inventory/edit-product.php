<?php
// 1. Start Session (if not done elsewhere reliably before output)
if (session_status() === PHP_SESSION_NONE) {
    session_start(); // Ensure session is started early
}

// 2. Include Core Config (Database needed for both GET and POST)
require_once 'config/database.php';

// --- Role Check (Example - Add if needed for this page) ---
// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
//     header('Location: dashboard.php?error=unauthorized');
//     exit();
// }
// --- End Role Check ---


// 3. Initialize Variables
$product_id = null;
$product = null; // Holds product data for the form
$categories = [];
$suppliers = [];
$error = ''; // For displaying general errors on the form
$validation_errors = []; // For specific field errors

// 4. Get and Validate Product ID from URL (Redirect if invalid BEFORE any output)
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: products.php?error=invalid_request');
    exit();
}
$product_id = (int)$_GET['id'];

// 5. Handle POST Request (Update Logic) - BEFORE fetching data for display
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Security check: Ensure ID in POST matches the ID from GET
    if (!isset($_POST['product_id']) || (int)$_POST['product_id'] !== $product_id) {
         header('Location: products.php?error=invalid_request');
         exit();
    }

    // --- Get Data from POST ---
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category_id = $_POST['category_id'] ?? null;
    $supplier_id = $_POST['supplier_id'] ?? null;
    $current_quantity = $_POST['current_quantity'] ?? 0;
    $min_quantity = $_POST['min_quantity'] ?? 0;
    $unit_price = $_POST['unit_price'] ?? 0.00;

    // --- Basic Validation (Add more as needed) ---
    if (empty($name)) $validation_errors['name'] = 'Product name is required.';
    if (empty($category_id) || !is_numeric($category_id)) $validation_errors['category_id'] = 'Please select a valid category.';
    if (empty($supplier_id) || !is_numeric($supplier_id)) $validation_errors['supplier_id'] = 'Please select a valid supplier.';
    if (!is_numeric($current_quantity) || $current_quantity < 0) $validation_errors['current_quantity'] = 'Current quantity must be a non-negative number.';
    if (!is_numeric($min_quantity) || $min_quantity < 0) $validation_errors['min_quantity'] = 'Minimum quantity must be a non-negative number.';
    if (!is_numeric($unit_price) || $unit_price < 0) $validation_errors['unit_price'] = 'Unit price must be a non-negative number.';
    // --- End Validation ---

    if (empty($validation_errors)) {
        try {
            $stmt = $pdo->prepare("
                UPDATE products
                SET name = ?, description = ?, category_id = ?, supplier_id = ?,
                    current_quantity = ?, min_quantity = ?, unit_price = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([
                $name,
                $description,
                $category_id,
                $supplier_id,
                $current_quantity,
                $min_quantity,
                $unit_price,
                $product_id
            ]);

            // *** SUCCESS: Redirect BEFORE any HTML ***
            header('Location: products.php?success=updated'); // This was line 46
            exit(); // IMPORTANT: Stop script execution immediately after redirect

        } catch (PDOException $e) {
            error_log("Error updating product (ID: $product_id): " . $e->getMessage());
            $error = "Error updating product. Database error occurred."; // General error for display
            // Keep POST data in variables to repopulate form if update fails
            $product = [
                'id' => $product_id, 'name' => $name, 'description' => $description,
                'category_id' => $category_id, 'supplier_id' => $supplier_id,
                'current_quantity' => $current_quantity, 'min_quantity' => $min_quantity,
                'unit_price' => $unit_price
            ];
        }
    } else {
         // Validation failed, prepare to show form again with errors
         $error = "Please correct the errors below.";
         // Keep POST data in variables to repopulate form
         $product = [
             'id' => $product_id, 'name' => $name, 'description' => $description,
             'category_id' => $category_id, 'supplier_id' => $supplier_id,
             'current_quantity' => $current_quantity, 'min_quantity' => $min_quantity,
             'unit_price' => $unit_price
         ];
    }
    // --- End POST Processing ---
}

// 6. Fetch Data for Display (Only if NOT a successful POST redirect)
// We only need to fetch from DB if $product is still null (i.e., it's a GET request or POST failed validation/db early)
if ($product === null) {
    try {
        // Fetch product details
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            // Redirect if product not found (BEFORE header include)
            header('Location: products.php?error=not_found');
            exit();
        }
    } catch (PDOException $e) {
         error_log("Error fetching product for edit (ID: $product_id): " . $e->getMessage());
         $error = "Could not load product data.";
         // Allow script to continue to show header/footer and error message
         $product = false; // Set product to false to prevent form display below
    }
}

// Fetch categories and suppliers regardless (needed for the form dropdowns)
// Only fetch if no critical error occurred earlier and we intend to show the form
if ($product !== false && (empty($error) || $error === "Please correct the errors below." || $error === "Error updating product. Database error occurred.")) {
    try {
        $categories = $pdo->query("SELECT id, name FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        $suppliers = $pdo->query("SELECT id, name FROM suppliers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
         error_log("Error fetching categories/suppliers for edit form: " . $e->getMessage());
         $error = "Could not load categories or suppliers.";
         $categories = []; // Ensure arrays exist
         $suppliers = [];
    }
}


// 7. Include Header (NOW safe to output HTML)
// Output starts HERE
require_once 'includes/header.php';
?>

<!-- 8. HTML Form -->
<div class="p-6">
    <div class="max-w-3xl mx-auto bg-white rounded-lg shadow">
        <div class="flex items-center justify-between p-4 border-b">
            <h2 class="text-lg font-semibold text-gray-800">Edit Product</h2>
        </div>

        <?php if (!empty($error)): ?>
            <div class="p-4 m-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($product): // Only show form if product data is available (either fetched or from failed POST) ?>
        <form method="POST" action="edit-product.php?id=<?= $product_id ?>" class="p-4 space-y-4">
             <input type="hidden" name="product_id" value="<?= $product_id ?>"> <!-- Add hidden field for POST check -->
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Product Name <span class="text-red-500">*</span></label>
                    <input type="text" name="name" value="<?= htmlspecialchars($product['name'] ?? '') ?>" required
                           class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['name']) ? 'border-red-500' : '' ?>">
                    <?php if (isset($validation_errors['name'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['name']) ?></p><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Category <span class="text-red-500">*</span></label>
                    <select name="category_id" required
                            class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['category_id']) ? 'border-red-500' : '' ?>">
                        <option value="">-- Select Category --</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= $category['id'] ?>"
                                    <?= isset($product['category_id']) && $category['id'] == $product['category_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($category['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                     <?php if (isset($validation_errors['category_id'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['category_id']) ?></p><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Supplier <span class="text-red-500">*</span></label>
                    <select name="supplier_id" required
                            class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['supplier_id']) ? 'border-red-500' : '' ?>">
                         <option value="">-- Select Supplier --</option>
                        <?php foreach ($suppliers as $supplier): ?>
                            <option value="<?= $supplier['id'] ?>"
                                    <?= isset($product['supplier_id']) && $supplier['id'] == $product['supplier_id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($supplier['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                     <?php if (isset($validation_errors['supplier_id'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['supplier_id']) ?></p><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Current Quantity <span class="text-red-500">*</span></label>
                    <input type="number" name="current_quantity" value="<?= htmlspecialchars($product['current_quantity'] ?? 0) ?>" required min="0"
                           class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['current_quantity']) ? 'border-red-500' : '' ?>">
                     <?php if (isset($validation_errors['current_quantity'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['current_quantity']) ?></p><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Minimum Quantity <span class="text-red-500">*</span></label>
                    <input type="number" name="min_quantity" value="<?= htmlspecialchars($product['min_quantity'] ?? 0) ?>" required min="0"
                           class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['min_quantity']) ? 'border-red-500' : '' ?>">
                     <?php if (isset($validation_errors['min_quantity'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['min_quantity']) ?></p><?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Unit Price <span class="text-red-500">*</span></label>
                    <input type="number" name="unit_price" value="<?= htmlspecialchars($product['unit_price'] ?? 0.00) ?>" required step="0.01" min="0"
                           class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 <?= isset($validation_errors['unit_price']) ? 'border-red-500' : '' ?>">
                     <?php if (isset($validation_errors['unit_price'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($validation_errors['unit_price']) ?></p><?php endif; ?>
                </div>
            </div>

            <div class="md:col-span-2"> <!-- Ensure description spans full width if needed -->
                <label class="block text-sm font-medium text-gray-700">Description</label>
                <textarea name="description" rows="3"
                          class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
            </div>

            <div class="flex justify-end pt-4 space-x-3">
                <a href="products.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">Cancel</a>
                <button type="submit" class="px-4 py-2 text-white transition rounded-md bg-royal-blue hover:bg-blue-700">
                    Update Product
                </button>
            </div>
        </form>
        <?php else: ?>
             <div class="p-4 text-center text-gray-500">
                 Product data could not be loaded or found. <a href="products.php" class="text-blue-600 hover:underline">Return to list</a>.
             </div>
        <?php endif; ?>
    </div>
</div>

<?php
// 9. Include Footer
require_once 'includes/footer.php';
?>
