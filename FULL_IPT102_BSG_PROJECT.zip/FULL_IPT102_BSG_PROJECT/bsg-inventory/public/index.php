<?php
/**
 * Front controller - Main entry point
 */
require __DIR__.'/../app/bootstrap.php';

// Route requests
$router = new Router();
$router->dispatch($_SERVER['REQUEST_URI']);