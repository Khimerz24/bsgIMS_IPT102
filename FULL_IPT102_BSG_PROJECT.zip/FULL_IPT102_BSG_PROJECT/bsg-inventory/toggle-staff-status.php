<?php
// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins to the dashboard with an error message
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the page code starts here ---
require_once 'config/database.php'; // If needed by this specific page
// require_once 'includes/header.php'; // This will be included AFTER the check if it's a display page

// --- Authorization Check ---
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect unauthorized users
    header('Location: login.php'); // Or dashboard with error
    exit();
}

// --- Validate Request ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id']) || !is_numeric($_POST['id']) || !isset($_POST['current_status'])) {
    header('Location: staff.php?error=invalid_request');
    exit();
}

$staff_id = (int)$_POST['id'];
$current_status = $_POST['current_status'];

// --- Prevent Self-Action ---
if ($staff_id === $_SESSION['user_id']) {
    header('Location: staff.php?error=self_action');
    exit();
}

// --- Determine New Status ---
$new_status = ($current_status === 'active') ? 'inactive' : 'active';

// --- Update Database ---
try {
    $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $staff_id]);

    if ($stmt->rowCount() > 0) {
        header('Location: staff.php?success=status_changed');
        exit();
    } else {
        // This might happen if the user ID doesn't exist, though unlikely if coming from the list
        header('Location: staff.php?error=not_found');
        exit();
    }
} catch (PDOException $e) {
    error_log("Error toggling staff status (ID: $staff_id): " . $e->getMessage());
    header('Location: staff.php?error=status_failed');
    exit();
}

?>
