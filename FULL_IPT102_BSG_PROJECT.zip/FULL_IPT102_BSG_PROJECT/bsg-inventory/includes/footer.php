</main> <!-- Close the main content section opened in header.php -->
        
        <footer class="py-4 text-center text-gray-500">
            © 2025 BSG Inventory System
        </footer>
        
    </div> <!-- Close the content-wrapper div -->
</div> <!-- Close the main-wrapper div -->

<script>
    // Mobile sidebar toggle functionality
    document.addEventListener('DOMContentLoaded', function() {
        const sidebarToggle = document.getElementById('sidebar-toggle');
        const sidebar = document.querySelector('.sidebar');
        
        if (sidebarToggle && sidebar) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('translate-x-0');
                sidebar.classList.toggle('-translate-x-full');
            });
        }
    });
</script>
</body>
</html>
