<?php
// Add the header include at the top of the file to ensure the page layout is properly displayed
require_once 'includes/header.php';

// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins to the dashboard with an error message
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the page code starts here ---
require_once 'config/database.php'; // If needed by this specific page
// require_once 'includes/header.php'; // This will be included AFTER the check if it's a display page

// --- Authorization Check ---
if ($_SESSION['role'] !== 'admin') {
    // Redirect non-admins to the dashboard or an error page
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Fetch Staff Data ---
try {
    $stmt = $pdo->query("SELECT id, username, role, status, created_at, last_login FROM users ORDER BY username ASC");
    $staff_members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching staff: " . $e->getMessage());
    // Display a user-friendly error message (optional)
    $fetch_error = "Could not retrieve staff data. Please try again later.";
    $staff_members = []; // Ensure $staff_members is an array
}

// --- Helper Function for Time Ago ---
function time_ago($timestamp) {
    if ($timestamp === null) {
        return 'Never';
    }
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes = round($seconds / 60);           // value 60 is seconds
    $hours = round($seconds / 3600);           //value 3600 is 60 minutes * 60 sec
    $days = round($seconds / 86400);          //86400=24*60*60
    $weeks = round($seconds / 604800);          //7*24*60*60;
    $months = round($seconds / 2629440);     //((365+365+365+365+366)/5/12)*24*60*60
    $years = round($seconds / 31553280);     //(365+365+365+365+366)/5 * 24 * 60 * 60

    if ($seconds <= 60) return "Just Now";
    else if ($minutes <= 60) return ($minutes == 1) ? "1 minute ago" : "$minutes minutes ago";
    else if ($hours <= 24) return ($hours == 1) ? "1 hour ago" : "$hours hours ago";
    else if ($days <= 7) return ($days == 1) ? "Yesterday" : "$days days ago";
    else if ($weeks <= 4.3) return ($weeks == 1) ? "A week ago" : "$weeks weeks ago"; // 4.3 == 30/7
    else if ($months <= 12) return ($months == 1) ? "A month ago" : "$months months ago";
    else return ($years == 1) ? "One year ago" : "$years years ago";
}

?>

<div class="container px-4 py-6 mx-auto">

    <!-- Page Title and Add Button -->
    <div class="flex flex-col items-center justify-between gap-4 mb-6 sm:flex-row">
        <h1 class="text-2xl font-semibold text-gray-800"></h1>
        <a href="add-staff.php" class="px-5 py-2 text-white transition duration-150 ease-in-out rounded-md bg-royal-blue hover:bg-primary-dark">
            <i class="mr-2 fas fa-plus"></i>Add New Staff
        </a>
    </div>

    <!-- Success/Error Messages -->
    <?php if (isset($_GET['success'])): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['success']) {
                'added' => 'Staff member added successfully.',
                'updated' => 'Staff member updated successfully.',
                'status_changed' => 'Staff member status changed successfully.',
                default => 'Operation successful.'
            }) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
         <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
             <?= htmlspecialchars(match($_GET['error']) {
                 'not_found' => 'Staff member not found.',
                 'update_failed' => 'Failed to update staff member.',
                 'add_failed' => 'Failed to add staff member.',
                 'status_failed' => 'Failed to change staff status.',
                 'self_action' => 'You cannot change your own status.',
                 'delete_failed' => 'Failed to manage staff member.', // Generic
                 default => 'An error occurred.'
             }) ?>
         </div>
    <?php endif; ?>
     <?php if (isset($fetch_error)): ?>
         <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
             <?= htmlspecialchars($fetch_error) ?>
         </div>
     <?php endif; ?>


    <!-- Staff Table -->
    <div class="overflow-hidden bg-white rounded-lg shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                 <thead class="text-xs uppercase table-header">
                    <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Username</th>
                        <th scope="col" class="px-6 py-3">Role</th>
                        <th scope="col" class="px-6 py-3">Status</th>
                        <th scope="col" class="px-6 py-3">Created</th>
                        <th scope="col" class="px-6 py-3">Last Login</th>
                        <th scope="col" class="px-6 py-3 text-center">Actions</th>
                    </tr>
                </thead>
                              <tbody>
                    <?php if (empty($staff_members) && !isset($fetch_error)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="7" class="px-6 py-4 text-center text-gray-500">No staff members found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($staff_members as $staff): ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                <td class="px-6 py-4"><?= htmlspecialchars($staff['id']) ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900"><?= htmlspecialchars($staff['username']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars(ucfirst($staff['role'])) ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?= $staff['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= ucfirst($staff['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4"><?= $staff['created_at'] ? date('M d, Y', strtotime($staff['created_at'])) : 'N/A' ?></td>

                                <!-- **** START MODIFICATION **** -->
                                                               <!-- **** START MODIFICATION **** -->
                                <td class="px-6 py-4">
                                    <?php
                                        $last_login_timestamp = $staff['last_login'];
                                        $last_login_display = time_ago($last_login_timestamp); // Get display text

                                        // Define the inline styles using the requested hex codes
                                        // Added contrasting text colors similar to the original theme
                                        $recent_style = 'background-color: #99FF7A; color: #166534;'; // Light green bg (#99FF7A), dark green text
                                        $not_recent_style = ' color: gray;'; // Light red bg (#FF9999), dark red text

                                        // Determine the style based on recency
                                        $last_login_style = $not_recent_style; // Default: Not recent or Never

                                        if ($last_login_timestamp !== null) {
                                            $time_diff_seconds = time() - strtotime($last_login_timestamp);
                                            // Check if login was within the last 24 hours (86400 seconds)
                                            if ($time_diff_seconds <= 86400) {
                                                $last_login_style = $recent_style; // Recent
                                            }
                                        }
                                    ?>
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium" style="<?= $last_login_style ?>">
                                        <?= $last_login_display ?>
                                    </span>
                                </td>
                                <!-- **** END MODIFICATION **** -->

                                <!-- **** END MODIFICATION **** -->

                                <td class="px-6 py-4 text-center whitespace-nowrap">
                                    <!-- Action Buttons (Existing Code) -->
                                    <a href="edit-staff.php?id=<?= $staff['id'] ?>"
                                       class="mr-3 text-indigo-600 hover:text-indigo-900" title="Edit">
                                        <i class="fas fa-edit fa-fw"></i>
                                    </a>
                                    <?php if ($staff['id'] != $_SESSION['user_id']): // Prevent self-deactivation/activation ?>
                                        <form class="inline" method="POST" action="toggle-staff-status.php"
                                              onsubmit="return confirm('Are you sure you want to <?= $staff['status'] === 'active' ? 'deactivate' : 'activate' ?> this user?');">
                                            <input type="hidden" name="id" value="<?= $staff['id'] ?>">
                                            <input type="hidden" name="current_status" value="<?= $staff['status'] ?>">
                                            <button type="submit"
                                                    class="<?= $staff['status'] === 'active' ? 'text-yellow-600 hover:text-yellow-900' : 'text-green-600 hover:text-green-900' ?>"
                                                    title="<?= $staff['status'] === 'active' ? 'Deactivate' : 'Activate' ?>">
                                                <i class="fas <?= $staff['status'] === 'active' ? 'fa-user-slash' : 'fa-user-check' ?> fa-fw"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-gray-400 cursor-not-allowed" title="Cannot change your own status">
                                            <i class="fas fa-user-slash fa-fw"></i>
                                        </span>
                                    <?php endif; ?>
                                    <!-- Optional Delete Button -->
                                </td>
                            </tr>
                        <?php endforeach; ?>
                     <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
