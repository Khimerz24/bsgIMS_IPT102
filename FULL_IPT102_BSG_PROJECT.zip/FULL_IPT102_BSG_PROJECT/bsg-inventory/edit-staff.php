<?php
// 1. Start Session and Check Role (BEFORE any other includes or output)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Role Check - This will EXIT if the user is not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit(); // <-- Script stops here for non-admins, hence no front-end
}

// 2. Include Database Config
require_once 'config/database.php';

// 3. Initialize Variables
$staff_id = null;
$username = '';
$role = '';
$status = '';
$errors = [];
$staff = null; // To hold fetched staff data

// 4. Get Staff ID from URL (Check and potentially exit BEFORE header)
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: staff.php?error=not_found');
    exit();
}
$staff_id = (int)$_GET['id'];

// 5. Handle Form Submission (BEFORE fetching data for display and BEFORE header include)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure the ID from POST matches the ID from GET for security
    if (!isset($_POST['id']) || (int)$_POST['id'] !== $staff_id) {
         header('Location: staff.php?error=invalid_request');
         exit();
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? '';
    $status = $_POST['status'] ?? '';

    // --- Validation ---
    if (empty($username)) {
        $errors['username'] = 'Username is required.';
    } else {
        // Check if new username conflicts with OTHERS
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$username, $staff_id]);
        if ($stmt->fetch()) {
            $errors['username'] = 'Username already taken by another user.';
        }
    }

    // Password validation (only if password fields are not empty)
    if (!empty($password)) {
         if (strlen($password) < 6) {
             $errors['password'] = 'Password must be at least 6 characters long.';
         } elseif ($password !== $confirm_password) {
            $errors['confirm_password'] = 'Passwords do not match.';
        }
    }

    if (!in_array($role, ['admin', 'staff'])) {
        $errors['role'] = 'Invalid role selected.';
    }
    if (!in_array($status, ['active', 'inactive'])) {
        $errors['status'] = 'Invalid status selected.';
    }

    // Prevent self-deactivation/role change if editing own profile
    if ($staff_id === $_SESSION['user_id']) {
        // Fetch current role/status again to prevent manipulation
        $selfStmt = $pdo->prepare("SELECT role, status FROM users WHERE id = ?");
        $selfStmt->execute([$staff_id]);
        $currentSelf = $selfStmt->fetch(PDO::FETCH_ASSOC);

        if ($status === 'inactive') {
             $errors['status'] = 'You cannot deactivate your own account.';
             $status = 'active'; // Force status back to active if attempted
        }
        // Optional: Prevent changing own role?
        // if ($role !== $currentSelf['role']) {
        //     $errors['role'] = 'You cannot change your own role.';
        //     $role = $currentSelf['role']; // Force role back
        // }
    }


    // --- Process if No Errors ---
    if (empty($errors)) {
        try {
            // Base query
            $sql = "UPDATE users SET username = ?, role = ?, status = ?";
            $params = [$username, $role, $status];

            // Add password update if provided
            if (!empty($password)) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $sql .= ", password = ?";
                $params[] = $hashed_password;
            }

            // Add WHERE clause
            $sql .= " WHERE id = ?";
            $params[] = $staff_id;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            // Redirect on success - BEFORE header include
            header('Location: staff.php?success=updated');
            exit(); // Stop script execution

        } catch (PDOException $e) {
            error_log("Error updating staff (ID: $staff_id): " . $e->getMessage());
            $errors['general'] = "Database error occurred. Could not update staff member.";
            // Let execution continue to display the form with the error
        }
    }
     // If validation errors occurred, execution continues below
}

// 6. Fetch Existing Staff Data (Only if not redirected)
try {
    // Fetch staff to edit
    $stmt = $pdo->prepare("SELECT id, username, role, status FROM users WHERE id = ?");
    $stmt->execute([$staff_id]);
    $staff = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$staff) {
        // Redirect if staff not found - BEFORE header include
        header('Location: staff.php?error=not_found');
        exit();
    }

    // Populate variables IF NOT a POST request (or if POST failed validation)
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !empty($errors)) {
        $username = $staff['username'] ?? '';
        $role = $staff['role'] ?? '';
        $status = $staff['status'] ?? '';
        // Password fields remain blank unless POST fails with password errors
    }

} catch (PDOException $e) {
    error_log("Error fetching staff for edit (ID: $staff_id): " . $e->getMessage());
    // Set error, but don't redirect yet, let header/footer load to show error
    $errors['fetch'] = "Could not load staff data.";
}


// 7. Include Header (NOW it's safe to display HTML)
require_once 'includes/header.php';
?>

<!-- 8. HTML Form Content -->
<div class="container px-4 py-6 mx-auto">
    <div class="max-w-2xl p-6 mx-auto bg-white rounded-lg shadow">
        <h1 class="mb-6 text-2xl font-semibold text-gray-800">Edit Staff Member: <?= htmlspecialchars($staff['username'] ?? '...') ?></h1>

        <?php if (!empty($errors['general'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['general']) ?>
            </div>
        <?php endif; ?>
         <?php if (!empty($errors['fetch'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['fetch']) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="edit-staff.php?id=<?= $staff_id ?>" class="space-y-4">
            <!-- Hidden ID for verification -->
            <input type="hidden" name="id" value="<?= $staff_id ?>">

            <!-- Username -->
            <div>
                <label for="username" class="block mb-1 text-sm font-medium text-gray-700">Username <span class="text-red-500">*</span></label>
                <input type="text" id="username" name="username" value="<?= htmlspecialchars($username) ?>" required
                       class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['username']) ? 'border-red-500' : 'border-gray-300' ?>">
                <?php if (isset($errors['username'])): ?>
                    <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['username']) ?></p>
                <?php endif; ?>
            </div>

            <!-- Password Change Section -->
             <div>
                <p class="mb-2 text-sm text-gray-600">Change Password (leave blank to keep current password)</p>
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                        <label for="password" class="block mb-1 text-sm font-medium text-gray-700">New Password</label>
                        <input type="password" id="password" name="password"
                               class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['password']) ? 'border-red-500' : 'border-gray-300' ?>">
                        <?php if (isset($errors['password'])): ?>
                            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['password']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label for="confirm_password" class="block mb-1 text-sm font-medium text-gray-700">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password"
                               class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['confirm_password']) ? 'border-red-500' : 'border-gray-300' ?>">
                        <?php if (isset($errors['confirm_password'])): ?>
                            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['confirm_password']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Role and Status -->
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                    <label for="role" class="block mb-1 text-sm font-medium text-gray-700">Role <span class="text-red-500">*</span></label>
                    <select id="role" name="role" required
                            class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['role']) ? 'border-red-500' : 'border-gray-300' ?>"
                            <?= ($staff_id === $_SESSION['user_id']) ? 'disabled title="Cannot change your own role"' : '' ?>>
                        <option value="staff" <?= $role === 'staff' ? 'selected' : '' ?>>Staff</option>
                        <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                     <?php if (isset($errors['role'])): ?>
                        <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['role']) ?></p>
                    <?php endif; ?>
                     <?php if ($staff_id === $_SESSION['user_id']): ?>
                         <!-- Add a hidden input to submit the current role if the dropdown is disabled -->
                         <input type="hidden" name="role" value="<?= htmlspecialchars($role) ?>" />
                         <p class="mt-1 text-xs text-gray-500">You cannot change your own role.</p>
                     <?php endif; ?>
                </div>
                 <div>
                    <label for="status" class="block mb-1 text-sm font-medium text-gray-700">Status <span class="text-red-500">*</span></label>
                    <select id="status" name="status" required
                            class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['status']) ? 'border-red-500' : 'border-gray-300' ?>"
                            <?= ($staff_id === $_SESSION['user_id']) ? 'disabled title="Cannot change your own status"' : '' ?> >
                        <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                     <?php if (isset($errors['status'])): ?>
                        <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['status']) ?></p>
                    <?php endif; ?>
                     <?php if ($staff_id === $_SESSION['user_id']): ?>
                         <!-- Add a hidden input to submit the current status if the dropdown is disabled -->
                         <input type="hidden" name="status" value="<?= htmlspecialchars($status) ?>" />
                         <p class="mt-1 text-xs text-gray-500">You cannot change your own status.</p>
                     <?php endif; ?>
                </div>
            </div>

            <!-- Buttons -->
            <div class="flex justify-end pt-4 space-x-3">
                <a href="staff.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">Cancel</a>
                <button type="submit" class="px-4 py-2 text-white transition rounded-md bg-royal-blue hover:bg-primary-dark">
                    Update Staff Member
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// 9. Include Footer
require_once 'includes/footer.php';
?>
