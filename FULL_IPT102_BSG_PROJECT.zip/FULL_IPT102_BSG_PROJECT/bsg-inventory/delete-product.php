<?php
// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the delete logic ---
require_once 'config/database.php';



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    try {
        // Start transaction
        $pdo->beginTransaction();

        // First check if product exists
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $product = $stmt->fetch();

        if (!$product) {
            header('Location: products.php?error=product-not-found');
            exit();
        }

        // First remove references from inventory_transactions
        $stmt = $pdo->prepare("DELETE FROM inventory_transactions WHERE product_id = ?");
        try {
            $stmt->execute([$_POST['id']]);
        } catch (PDOException $e) {
            // If table doesn't exist or other error, continue
        }

        // Remove references from order_items
        $stmt = $pdo->prepare("DELETE FROM order_items WHERE product_id = ?");
        try {
            $stmt->execute([$_POST['id']]);
        } catch (PDOException $e) {
            // If table doesn't exist or other error, continue
        }

        // Finally delete the product
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$_POST['id']]);

        // Commit the transaction
        $pdo->commit();

        header('Location: products.php?success=deleted');
        exit();
    } catch (PDOException $e) {
        // Rollback the transaction if something failed
        $pdo->rollBack();
        
        // Log the error for debugging
        error_log("Error deleting product: " . $e->getMessage());
        
        // If it's a foreign key constraint error
         // If it's a foreign key constraint error
    if ($e->getCode() == '23000') { // <--- THIS PART
        // Instead of deleting, mark as inactive or archived
        try {
            $stmt = $pdo->prepare("UPDATE products SET status = 'inactive' WHERE id = ?"); // <--- SETS STATUS
            $stmt->execute([$_POST['id']]);
            header('Location: products.php?success=archived'); // <--- REDIRECTS WITH 'archived'
            exit();
        } catch (PDOException $e2) {
            header('Location: products.php?error=update-failed');
            exit();
        }
    }
      header('Location: products.php?error=delete-failed');
    exit();
    }
}

header('Location: products.php');
exit();

