<?php

// --- Role Check (must occur before any output) ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Include Database Config Only ---
require_once 'config/database.php';

// --- Fetch categories and suppliers for dropdowns ---
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$suppliers  = $pdo->query("SELECT * FROM suppliers ORDER BY name")->fetchAll();

// --- Initialize error variable ---
$error = '';

// --- Handle Form Submission (must occur before any output) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO products (name, description, category_id, supplier_id, current_quantity, min_quantity, unit_price, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
        );
        $stmt->execute([
            $_POST['name'],
            $_POST['description'],
            $_POST['category_id'],
            $_POST['supplier_id'],
            $_POST['current_quantity'],
            $_POST['min_quantity'],
            $_POST['unit_price']
        ]);

        header('Location: products.php?success=added');
        exit();
    } catch (PDOException $e) {
        $error = "Error adding product: " . $e->getMessage();
    }
}

// --- Include Header After Logic ---
require_once 'includes/header.php';
?>

<div class="p-6">
    <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg">
        <div class="p-4 rounded-t-lg bg-primary-light">
            <h2 class="text-2xl font-bold text-gray-800">Add New Product</h2>
        </div>

        <?php if (!empty($error)): ?>
            <div class="px-4 py-3 mb-4 text-red-700 bg-red-100 border border-red-400 rounded">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="p-6 space-y-6 rounded-b-lg bg-gray-50">
            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="name">Product Name</label>
                    <input id="name" type="text" name="name" placeholder="e.g., Wireless Mouse" required
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="category_id">Category</label>
                    <select id="category_id" name="category_id" required
                            class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="supplier_id">Supplier</label>
                    <select id="supplier_id" name="supplier_id" required
                            class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                        <?php foreach ($suppliers as $sup): ?>
                            <option value="<?= $sup['id'] ?>"><?= htmlspecialchars($sup['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="current_quantity">Current Quantity</label>
                    <input id="current_quantity" type="number" name="current_quantity" placeholder="e.g., 100" required min="0"
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="min_quantity">Minimum Quantity</label>
                    <input id="min_quantity" type="number" name="min_quantity" placeholder="e.g., 10" required min="0"
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="unit_price">Unit Price</label>
                    <input id="unit_price" type="number" name="unit_price" placeholder="e.g., 29.99" required step="0.01" min="0"
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                </div>

                <div class="col-span-full">
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="description">Description</label>
                    <textarea id="description" name="description" rows="4" placeholder="Product details..."
                              class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"></textarea>
                </div>
            </div>

            <div class="flex flex-col justify-end space-y-3 md:flex-row md:space-y-0 md:space-x-4">
                <a href="products.php"
                   class="px-6 py-3 text-lg font-medium text-center text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">Cancel</a>
                <button type="submit"
                        class="px-6 py-3 text-lg font-semibold text-white rounded-lg bg-royal-blue hover:bg-blue-700">Add Product</button>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
