<?php
// 1. Start Session and Check Role (BEFORE any other includes or output)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Role Check - This will EXIT if the user is not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit(); // <-- Script stops here for non-admins
}

// 2. Include Database Config
require_once 'config/database.php';

// 3. Initialize Variables
$supplier_id = null;
$name = $contact_person = $email = $phone = $address = $status = '';
$errors = [];
$supplier = null; // To hold fetched supplier data

// 4. Get Supplier ID from URL (Check and potentially exit BEFORE header)
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: suppliers.php?error=not_found');
    exit();
}
$supplier_id = (int)$_GET['id'];

// 5. Handle Form Submission (BEFORE fetching data for display and BEFORE header include)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure the ID from POST matches the ID from GET for security
    if (!isset($_POST['id']) || (int)$_POST['id'] !== $supplier_id) {
         header('Location: suppliers.php?error=invalid_request');
         exit();
    }

    // Sanitize and retrieve form data
    $name = trim($_POST['name'] ?? '');
    $contact_person = trim($_POST['contact_person'] ?? '');
    $email = trim($_POST['email'] ?? '');
$contact_number = trim($_POST['contact_number'] ?? '');    
$address = trim($_POST['address'] ?? '');
    $status = $_POST['status'] ?? 'active';

    // Basic Validation
    if (empty($name)) $errors['name'] = 'Supplier name is required.';
    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Invalid email format.';
    // Add other validation as needed (phone format, etc.)
    if (!in_array($status, ['active', 'inactive'])) $errors['status'] = 'Invalid status selected.';


    // --- Process if No Errors ---
    if (empty($errors)) {
        try {
            $sql = "UPDATE suppliers SET
                        name = :name,
                        contact_person = :contact_person,
                        email = :email,
                        contact_number = :contact_number,
                        address = :address,
                        status = :status,
                        updated_at = NOW()
                    WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':name' => $name,
                ':contact_person' => empty($contact_person) ? null : $contact_person,
                ':email' => empty($email) ? null : $email,
                ':contact_number' => empty($contact_number) ? null : $contact_number,
                ':address' => empty($address) ? null : $address,
                ':status' => $status,
                ':id' => $supplier_id
            ]);

            // Redirect on success - BEFORE header include
            header('Location: suppliers.php?success=updated');
            exit(); // Stop script execution

        } catch (PDOException $e) {
    error_log("Error updating supplier (ID: $supplier_id): " . $e->getMessage());

    // Set YOUR custom, generic error message for the user
$errors['database'] = "Database error occurred. Could not update supplier.";

}

    }
     // If validation errors occurred, execution continues below
}

// 6. Fetch Existing Supplier Data (Only if not redirected)
try {
    // Fetch supplier to edit
    $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
    $stmt->execute([$supplier_id]);
    $supplier = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$supplier) {
        // Redirect if supplier not found - BEFORE header include
        header('Location: suppliers.php?error=not_found');
        exit();
    }

    // Populate variables IF NOT a POST request (or if POST failed validation)
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !empty($errors)) {
        $name = $supplier['name'] ?? '';
        $contact_person = $supplier['contact_person'] ?? '';
        $email = $supplier['email'] ?? '';
        $contact_number = $supplier['contact_number'] ?? '';
        $address = $supplier['address'] ?? '';
        $status = $supplier['status'] ?? 'active';
    }

} catch (PDOException $e) {
    error_log("Error fetching supplier for edit (ID: $supplier_id): " . $e->getMessage());
    // Set error, but don't redirect yet, let header/footer load to show error
    $errors['fetch'] = "Could not load supplier data.";
}


// 7. Include Header (NOW it's safe to display HTML)
require_once 'includes/header.php';
?>

<!-- 8. HTML Form Content -->
<div class="container px-4 py-6 mx-auto">
    <div class="max-w-2xl p-6 mx-auto bg-white rounded-lg shadow">
        <h1 class="mb-6 text-2xl font-semibold text-gray-800">Edit Supplier: <?= htmlspecialchars($supplier['name'] ?? '...') ?></h1>

        <?php if (!empty($errors['database'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['database']) ?>
            </div>
        <?php endif; ?>
         <?php if (!empty($errors['fetch'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['fetch']) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="edit-supplier.php?id=<?= $supplier_id ?>" class="space-y-4">
             <!-- Hidden ID for verification -->
            <input type="hidden" name="id" value="<?= $supplier_id ?>">

            <!-- Name -->
            <div>
                <label for="name" class="block mb-1 text-sm font-medium text-gray-700">Supplier Name <span class="text-red-500">*</span></label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required
                       class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['name']) ? 'border-red-500' : 'border-gray-300' ?>">
                <?php if (isset($errors['name'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['name']) ?></p><?php endif; ?>
            </div>

            <!-- Contact Person -->
            <div>
                <label for="contact_person" class="block mb-1 text-sm font-medium text-gray-700">Contact Person</label>
                <input type="text" id="contact_person" name="contact_person" value="<?= htmlspecialchars($contact_person) ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
            </div>

            <!-- Email -->
            <div>
                <label for="email" class="block mb-1 text-sm font-medium text-gray-700">Email</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>"
                       class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['email']) ? 'border-red-500' : 'border-gray-300' ?>">
                 <?php if (isset($errors['email'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['email']) ?></p><?php endif; ?>
            </div>

            <!-- Contact Number -->
           <div>
    <label for="contact_number" class="block mb-1 text-sm font-medium text-gray-700">Contact Number</label>
    <input type="tel" id="contact_number" name="contact_number" value="<?= htmlspecialchars($contact_number) ?>"
           class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
</div>


            <!-- Address -->
            <div>
                <label for="address" class="block mb-1 text-sm font-medium text-gray-700">Address</label>
                <textarea id="address" name="address" rows="3"
                          class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"><?= htmlspecialchars($address) ?></textarea>
            </div>

             <!-- Status -->
            <div>
                <label for="status" class="block mb-1 text-sm font-medium text-gray-700">Status <span class="text-red-500">*</span></label>
                <select id="status" name="status" required
                        class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['status']) ? 'border-red-500' : 'border-gray-300' ?>">
                    <option value="active" <?= ($status === 'active') ? 'selected' : '' ?>>Active</option>
                    <option value="inactive" <?= ($status === 'inactive') ? 'selected' : '' ?>>Inactive</option>
                </select>
                 <?php if (isset($errors['status'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['status']) ?></p><?php endif; ?>
            </div>


            <!-- Buttons -->
            <div class="flex justify-end pt-4 space-x-3">
                <a href="suppliers.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">Cancel</a>
                <button type="submit" class="px-4 py-2 text-white transition rounded-md bg-royal-blue hover:bg-primary-dark">
                    Update Supplier
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// 9. Include Footer
require_once 'includes/footer.php';
?>
