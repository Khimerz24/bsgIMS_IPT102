<?php
// 1. Start Session and Check Role (Admin only)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// 2. Include Database Config
require_once 'config/database.php';

// 3. Initialize variables
$product_id = '';
$quantity_added = '';
$notes = '';
$errors = [];
$products_list = []; // For the dropdown

// 4. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = trim($_POST['product_id'] ?? '');
    $quantity_added = trim($_POST['quantity_added'] ?? '');
    $notes = trim($_POST['notes'] ?? '');
    $user_id = $_SESSION['user_id']; // Get current admin user ID

    // --- Validation ---
    if (empty($product_id) || !is_numeric($product_id)) {
        $errors['product_id'] = 'Please select a valid product.';
    }
    if (empty($quantity_added) || !is_numeric($quantity_added) || $quantity_added <= 0) {
        $errors['quantity_added'] = 'Please enter a valid quantity (must be greater than 0).';
    }
    if (is_numeric($quantity_added) && $quantity_added > 999999) {
         $errors['quantity_added'] = 'Quantity seems too large. Please check.';
    }


    // --- Process if No Errors ---
    if (empty($errors)) {
        // --- TRANSACTION START ---
        $pdo->beginTransaction();
        try {
            // --- Step 1: Insert into stock_entries log ---
            $sqlLog = "INSERT INTO stock_entries (product_id, quantity_added, user_id, notes, entry_date)
                       VALUES (:product_id, :quantity_added, :user_id, :notes, NOW())";
            $stmtLog = $pdo->prepare($sqlLog);
            $stmtLog->execute([
                ':product_id' => $product_id,
                ':quantity_added' => $quantity_added,
                ':user_id' => $user_id,
                ':notes' => empty($notes) ? null : $notes // Store NULL if notes are empty
            ]);
            // --- End Step 1 ---

            // --- Step 2: Update the current_quantity in the products table ---
            $sqlProd = "UPDATE products
                        SET current_quantity = current_quantity + :quantity_added,
                            updated_at = NOW()
                        WHERE id = :product_id";
            $stmtProd = $pdo->prepare($sqlProd);
            $stmtProd->execute([
                ':quantity_added' => $quantity_added, // Use the same quantity
                ':product_id' => $product_id
            ]);
            // --- End Step 2 ---

            // Check if the product update actually affected a row
            if ($stmtProd->rowCount() === 0) {
                // This could happen if the product_id was invalid or deleted concurrently
                throw new Exception("Failed to update product quantity. Product might not exist.");
            }

            // --- Step 3: Commit Transaction ---
            $pdo->commit();
            // --- TRANSACTION END ---

            // Redirect on success
            header('Location: products.php?success=stock_added&prod_id=' . $product_id);
            exit();

        } catch (PDOException | Exception $e) { // Catch both PDO and general exceptions
            // --- Rollback on Error ---
            $pdo->rollBack();
            error_log("Error adding stock (Product ID: $product_id, Qty: $quantity_added): " . $e->getMessage());
            // Provide more detail for debugging if needed
            $errors['database'] = "Database error occurred. Could not add stock. Details: " . htmlspecialchars($e->getMessage());
            // Let execution continue to display the form with the error
        }
    }
    // If validation errors occurred, execution continues below
}

// ... (Rest of the file: Fetching products for dropdown, including header, HTML form, footer) ...

// 5. Fetch Products for dropdown (Only if not redirected)
try {
    $productStmt = $pdo->query("SELECT id, name, current_quantity FROM products ORDER BY name ASC");
    $products_list = $productStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching products for stock form: " . $e->getMessage());
    $errors['fetch'] = "Could not load product list.";
}

// 6. Include Header (NOW it's safe)
require_once 'includes/header.php';
?>

<!-- 7. HTML Form Content -->
<div class="container px-4 py-6 mx-auto">
    <div class="max-w-lg p-6 mx-auto bg-white rounded-lg shadow">
        <h1 class="mb-6 text-2xl font-semibold text-gray-800">Add Quantity/Stock</h1>

        <?php if (!empty($errors['database'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= $errors['database'] /* Already contains htmlspecialchars if needed */ ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($errors['fetch'])): ?>
            <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['fetch']) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="add-stock.php" class="space-y-4">
            
             <!-- Product Selection -->
            <div>
                <label for="product_id" class="block mb-1 text-sm font-medium text-gray-700">Product <span class="text-red-500">*</span></label>
                <select id="product_id" name="product_id" required
                        class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['product_id']) ? 'border-red-500' : 'border-gray-300' ?>">
                    <option value="">-- Select Product --</option>
                    <?php foreach ($products_list as $prod): ?>
                        <option value="<?= $prod['id'] ?>" <?= ($product_id == $prod['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($prod['name']) ?> (Current: <?= $prod['current_quantity'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (isset($errors['product_id'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['product_id']) ?></p><?php endif; ?>
            </div>

            <!-- Quantity Added -->
            <div>
                <label for="quantity_added" class="block mb-1 text-sm font-medium text-gray-700">Quantity Added <span class="text-red-500">*</span></label>
                <input type="number" id="quantity_added" name="quantity_added" min="1" step="1" value="<?= htmlspecialchars($quantity_added) ?>" required
                       class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['quantity_added']) ? 'border-red-500' : 'border-gray-300' ?>">
                <?php if (isset($errors['quantity_added'])): ?><p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['quantity_added']) ?></p><?php endif; ?>
            </div>

        

            <!-- Buttons -->
            <div class="flex justify-end pt-4 space-x-3">
                <a href="products.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">Cancel</a>
                <button type="submit" class="px-4 py-2 text-white transition bg-green-600 rounded-md hover:bg-green-700">
                    <i class="mr-1 fas fa-plus"></i> Add Stock 
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// 8. Include Footer
require_once 'includes/footer.php';
?>
