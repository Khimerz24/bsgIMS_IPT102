<?php
require_once 'includes/header.php'; // Session started, user logged in
require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// --- Fetch Sales Data ---
try {
    $sql = "SELECT sr.id, sr.sale_date, sr.status, sr.total_amount, u_staff.username as staff_name, u_admin.username as admin_name
            FROM sales_records sr
            JOIN users u_staff ON sr.staff_user_id = u_staff.id
            LEFT JOIN users u_admin ON sr.approved_by_user_id = u_admin.id";

    $params = [];

    // Filter for staff: only show their own records
    if ($user_role === 'staff') {
        $sql .= " WHERE sr.staff_user_id = ?";
        $params[] = $user_id;
    }

    // Add filtering options (Example: by status)
    $filter_status = $_GET['status'] ?? '';
    if ($filter_status && in_array($filter_status, ['pending', 'approved', 'rejected'])) {
         $sql .= ($user_role === 'staff') ? " AND sr.status = ?" : " WHERE sr.status = ?";
         $params[] = $filter_status;
    }


    $sql .= " ORDER BY sr.sale_date DESC"; // Show most recent first

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $sales_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching sales records: " . $e->getMessage());
    $fetch_error = "Could not retrieve sales data. Please try again later.";
    $sales_records = [];
}

// --- Helper Function for Status Badge ---
function getStatusBadgeClass($status) {
    return match ($status) {
        'approved' => 'bg-green-100 text-green-800',
        'rejected' => 'bg-red-100 text-red-800',
        'pending' => 'bg-yellow-100 text-yellow-800',
        default => 'bg-gray-100 text-gray-800',
    };
}
?>

<div class="container px-4 py-6 mx-auto">

    <!-- Page Title and Actions -->
    <div class="flex flex-col items-center justify-between gap-4 mb-6 sm:flex-row">
        <p class="text-2xl font-semibold text-gray-800"></p>
        <div class="flex gap-2">
             <a href="add-sale.php" class="px-5 py-2 text-white transition duration-150 ease-in-out rounded-md bg-royal-blue hover:bg-primary-dark">
                <i class="mr-2 fas fa-plus"></i>Record New Sale
            </a>
            <?php if ($user_role === 'admin'): ?>
            <!-- Maybe add admin-specific actions here later -->
            <?php endif; ?>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if (isset($_GET['success'])): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['success']) {
                'recorded' => 'Sale recorded successfully and is pending approval.',
                'approved' => 'Sale approved successfully and inventory updated.',
                'rejected' => 'Sale rejected successfully.',
                default => 'Operation successful.'
            }) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
         <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
             <?= htmlspecialchars(match($_GET['error']) {
                 'record_failed' => 'Failed to record sale.',
                 'approve_failed' => 'Failed to approve sale.',
                 'reject_failed' => 'Failed to reject sale.',
                 'not_found' => 'Sale record not found.',
                 'invalid_status' => 'Invalid status for this operation.',
                 'stock_error' => 'Insufficient stock for one or more items during approval.',
                 'db_error' => 'A database error occurred.',
                 default => 'An error occurred.'
             }) ?>
         </div>
    <?php endif; ?>
     <?php if (isset($fetch_error)): ?>
         <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
             <?= htmlspecialchars($fetch_error) ?>
         </div>
     <?php endif; ?>

    <!-- Filter Form -->
    <div class="p-4 mb-6 bg-white rounded-lg shadow">
        <form method="GET" action="sales.php" class="flex flex-col items-end gap-4 sm:flex-row">
            <div>
                <label for="status_filter" class="block mb-1 text-sm font-medium text-gray-700">Filter by Status</label>
                <select id="status_filter" name="status" class="w-full border-gray-300 rounded-md shadow-sm sm:w-48 focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                    <option value="">All Statuses</option>
                    <option value="pending" <?= ($filter_status === 'pending') ? 'selected' : '' ?>>Pending</option>
                    <option value="approved" <?= ($filter_status === 'approved') ? 'selected' : '' ?>>Approved</option>
                    <option value="rejected" <?= ($filter_status === 'rejected') ? 'selected' : '' ?>>Rejected</option>
                </select>
            </div>
            <button type="submit" class="px-4 py-2 text-white transition bg-gray-600 rounded-md hover:bg-gray-700">
                Filter
            </button>
             <a href="sales.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">
                Clear Filter
            </a>
        </form>
    </div>


    <!-- Sales Table -->
    <div class="overflow-hidden bg-white rounded-lg shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                <thead class="text-xs uppercase table-header">
                    <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Date</th>
                        <?php if ($user_role === 'admin'): ?>
                            <th scope="col" class="px-6 py-3">Staff</th>
                        <?php endif; ?>
                        <th scope="col" class="px-6 py-3">Total Amount</th>
                        <th scope="col" class="px-6 py-3">Status</th>
                        <?php if ($user_role === 'admin'): ?>
                            <th scope="col" class="px-6 py-3">Processed By</th>
                        <?php endif; ?>
                        <th scope="col" class="px-6 py-3 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sales_records) && !isset($fetch_error)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="<?= $user_role === 'admin' ? 7 : 5 ?>" class="px-6 py-4 text-center text-gray-500">No sales records found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($sales_records as $record): ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                <td class="px-6 py-4 font-medium text-gray-900"><?= htmlspecialchars($record['id']) ?></td>
                                <td class="px-6 py-4"><?= date('M d, Y H:i', strtotime($record['sale_date'])) ?></td>
                                <?php if ($user_role === 'admin'): ?>
                                    <td class="px-6 py-4"><?= htmlspecialchars($record['staff_name']) ?></td>
                                <?php endif; ?>
                                <td class="px-6 py-4">₱<?= number_format($record['total_amount'], 2) ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?= getStatusBadgeClass($record['status']) ?>">
                                        <?= ucfirst($record['status']) ?>
                                    </span>
                                </td>
                                 <?php if ($user_role === 'admin'): ?>
                                    <td class="px-6 py-4"><?= htmlspecialchars($record['admin_name'] ?? 'N/A') ?></td>
                                <?php endif; ?>
                                <td class="px-6 py-4 text-center whitespace-nowrap">
                                    <a href="view-sale.php?id=<?= $record['id'] ?>"
                                       class="text-indigo-600 hover:text-indigo-900" title="View Details">
                                        <i class="fas fa-eye fa-fw"></i>
                                    </a>
                                    <?php if ($user_role === 'admin' && $record['status'] === 'pending'): ?>
                                        <!-- Quick Actions (Optional) -->
                                        <form class="inline ml-2" method="POST" action="approve-sale.php" onsubmit="return confirm('Are you sure you want to APPROVE this sale? Inventory will be updated.');">
                                            <input type="hidden" name="sales_record_id" value="<?= $record['id'] ?>">
                                            <button type="submit" class="text-green-600 hover:text-green-900" title="Approve">
                                                <i class="fas fa-check-circle fa-fw"></i>
                                            </button>
                                        </form>
                                         <form class="inline ml-2" method="POST" action="reject-sale.php" onsubmit="return confirm('Are you sure you want to REJECT this sale?');">
                                            <input type="hidden" name="sales_record_id" value="<?= $record['id'] ?>">
                                            <!-- You could add a quick reject reason input here if desired -->
                                            <button type="submit" class="text-red-600 hover:text-red-900" title="Reject">
                                                <i class="fas fa-times-circle fa-fw"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                     <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
