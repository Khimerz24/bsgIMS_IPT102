<?php
require_once 'includes/header.php';
require_once 'config/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) { // Only check if logged in
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: products.php');
    exit();
}

$product_id = $_GET['id'];

$stmt = $pdo->prepare("
    SELECT p.*, c.name as category_name, s.name as supplier_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN suppliers s ON p.supplier_id = s.id
    WHERE p.id = ?
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit();
}
?>

<div class="p-6">
    <div class="max-w-3xl mx-auto bg-white rounded-lg shadow">
      <div class="flex items-center justify-between p-4 border-b">
    <h2 class="text-lg font-semibold text-gray-800">Product Details</h2>
    <div class="space-x-2">
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="edit-product.php?id=<?= $product['id'] ?>"
               class="px-4 py-2 text-white rounded-md bg-royal-blue hover:bg-blue-700">
                Edit
            </a>
        <?php endif; ?>
        <a href="products.php"
           class="px-6 py-2 text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
            <i class="fas fa-arrow-left"></i> Back <!-- Changed icon for consistency -->
        </a>
    </div>
</div>

        
        <div class="p-4 space-y-4">
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-500">Product Name</label>
                    <p class="mt-1 text-lg"><?= htmlspecialchars($product['name']) ?></p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-500">Category</label>
                    <p class="mt-1 text-lg"><?= htmlspecialchars($product['category_name']) ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-500">Supplier</label>
                    <p class="mt-1 text-lg"><?= htmlspecialchars($product['supplier_name']) ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-500">Current Quantity</label>
                    <p class="mt-1 text-lg"><?= $product['current_quantity'] ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-500">Minimum Quantity</label>
                    <p class="mt-1 text-lg"><?= $product['min_quantity'] ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-500">Unit Price</label>
                    <p class="mt-1 text-lg">₱<?= number_format($product['unit_price'], 2) ?></p>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium text-gray-500">Description</label>
                <p class="mt-1 text-lg"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
            </div>
        </div>
    </div>
</div>