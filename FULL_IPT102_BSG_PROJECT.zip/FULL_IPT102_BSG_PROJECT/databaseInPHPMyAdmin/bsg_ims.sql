-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2025 at 03:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsg_ims`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Beverages', 'Drinks including coffee, tea, soft drinks, and water', '2025-04-15 23:21:39', NULL),
(2, 'Snack Foods', 'Packaged foods, snacks, and confectionery items', '2025-04-15 23:21:39', '2025-04-17 11:49:41'),
(3, 'Personal Care', 'Hygiene, grooming, wellness, beauty, self-maintenance, confidence.', '2025-04-15 23:21:39', '2025-04-17 21:34:33'),
(4, 'Automotive Lubricants', 'Engine protection, performance, friction reduction, longevity.', '2025-04-15 23:21:39', '2025-04-17 21:34:39'),
(5, 'Automotive Parts/Accessories', 'Performance, customization, safety, enhancement, durability, reliability.', '2025-04-17 11:51:47', '2025-04-17 21:34:45');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `current_quantity` int(11) NOT NULL DEFAULT 0,
  `min_quantity` int(11) NOT NULL DEFAULT 5,
  `unit_price` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `category_id`, `supplier_id`, `sku`, `current_quantity`, `min_quantity`, `unit_price`, `created_at`, `updated_at`, `status`) VALUES
(16, 'BOY BAWANG 100G', '', 2, 6, NULL, 23, 10, 25.00, '2025-04-18 10:49:10', '2025-04-21 23:42:07', 'inactive'),
(115, 'BEAR BRAND STERILIZED 300ML', '', 1, 6, NULL, 0, 5, 60.00, '2025-04-21 23:54:45', '2025-04-22 00:18:45', 'active'),
(116, 'BEAR BRAND SWAK PACK 33G', '', 1, 6, NULL, 0, 5, 20.00, '2025-04-21 23:54:45', '2025-04-22 00:19:40', 'active'),
(117, 'BODY MAMA 26G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:20:32', 'active'),
(118, 'BOY BAWANG 100G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:56:52', 'active'),
(119, 'BOY BAWANG 100G ROASTED NUTS', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:57:06', 'active'),
(120, 'BOY BAWANG CHICHARAP 40G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:00:26', 'active'),
(121, 'BOY BAWANG MIXED NUTS GARLIC', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:00:37', 'active'),
(122, 'BREAD PAN BUTTER 24G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:05:28', 'active'),
(123, 'BREAD PAN BUTTER 42G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:06:34', 'active'),
(124, 'BREAD PAN CHEESE 24G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:06:45', 'active'),
(125, 'BREAD PAN CHEESE 42G', '', 2, 6, NULL, 15, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:35:12', 'active'),
(126, 'BREAD PAN GARLIC 24G', '', 2, 6, NULL, 15, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:35:28', 'active'),
(127, 'BREAD PAN GARLIC 42G', '', 2, 6, NULL, 5, 5, 12.00, '2025-04-21 23:54:45', '2025-04-22 00:35:35', 'active'),
(128, 'BREAD PAN WHEAT 24G', '', 2, 6, NULL, 0, 5, 12.00, '2025-04-21 23:54:45', '2025-04-22 00:34:14', 'active'),
(129, 'BREAD PAN WHEAT CHEDDAR 42G', NULL, 2, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(130, 'CHARMEE PANTY LINER GREENTEA', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:45:35', 'active'),
(131, 'CHARMEE SANITARY NAPKIN 8\'S', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:45:57', 'active'),
(132, 'CHARMEE SINGLE', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:45:46', 'active'),
(133, 'CHEESE RING 80G', '', 2, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:07:36', 'active'),
(134, 'CHEEZY SNACK 20G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(135, 'CHIZ CURLS 18G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(136, 'CHIZ CURLS 25G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(137, 'COLGATE OMG 250ML', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:44:52', 'active'),
(138, 'COLGATE TOOTHBRUSH', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:44:19', 'active'),
(139, 'COLGATE TWIN PACK', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:45:04', 'active'),
(140, 'CREAM SILK 22G', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:46:36', 'active'),
(141, 'CRISPY PATATA 25G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(142, 'DM FIBER 220ML', NULL, 3, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(143, 'DM FOUR SEASON 230ML', NULL, 3, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(144, 'DM PINEAPPLE ACE 240ML', NULL, 3, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(145, 'DM PINEAPPLE HEART SMART 240ML', NULL, 3, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(146, 'EQ ECONOMY & QUALITY DIAPERS', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:45:21', 'active'),
(147, 'FARLIN WIPES 10\'S', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:46:28', 'active'),
(148, 'FARLIN WIPES 30\'S', '', 3, 6, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:44:40', 'active'),
(149, 'FISCO CHOCO MALLOWS 36G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(150, 'FISCO CHOCOLATE CHIP 36G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(151, 'FISCO CHOCOLATE CHIP 80G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(152, 'FUDGEE BARR CHOCOLATE 39G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(153, 'FUDGEE BARR MACAPUNO 39G', NULL, 1, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(154, 'GATORADE 500ML', NULL, 3, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(155, 'LUBRICANT 2T SCENTED 200ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(156, 'LUBRICANT 2T SCENTED 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(157, 'PLATINUM ATF MP DEXRON III 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(158, 'PLATINUM ATF MP DEXRON III 4L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(159, 'PLATINUM ATF SP III 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(160, 'PLATINUM ATF SP III 4L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(161, 'PLATINUM ATF MV 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(162, 'REPSOL MOTO 4T RIDER 20W50 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(163, 'WHEEL BEARING ATT 12X32', NULL, 7, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(164, 'WHEEL BEARING ATT 12X37', NULL, 7, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(165, 'MULTI S 3134F', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(166, 'AZOLLA ZS 68 18L', '', 5, 7, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:56:24', 'active'),
(167, 'ELF PERF MOTO 4T 20W50 1L', '', 5, 7, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-22 00:07:03', 'active'),
(168, 'PLATINUM GEAR OIL GL4 90 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(169, 'PLATINUM GEAR OIL GL4 90 17L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(170, 'PLATINUM GEAR OIL GL5 90 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(171, 'PLATINUM GEAR OIL GL5 90 17L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(172, 'SURE BRAKE FLUID DOT3 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(173, 'SURE BRAKE FLUID DOT4 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(174, 'NATIONAL CFHD ND 103 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(175, 'NATIONAL CFHD ND 103 17L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(176, 'NATIONAL 2T NLSCO 60X200ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(177, 'PLATINUM MGO 220ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(178, 'NATIONAL BRAKE FLUID DOT3 300ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(179, 'NATIONAL BRAKE FLUID DOT4 300ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(180, 'PLATINUM 2T EURO 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(181, 'NATIONAL #510002 2T NS-501 2LX1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(182, 'TOTAL 2T MCO 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(183, 'TOTAL 2T MCO 20X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(184, 'TOTAL HI PERF 4T SUPER 20W50 18X800ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(185, 'TOTAL HI PERF 4T SUPER 20W50 28X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(186, 'TOTAL HI PERF SAE 40 (MCCO 4T) 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(187, 'TOTAL HI PERF SAE 40 (MCCO 4T) 18X800ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(188, 'TOTAL HI PERF 4T SCOOTER 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(189, 'TOTAL HI PERF 4T SCOOTER 18X800ML', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(190, 'TOTAL HI-PERF 4T SPORT 10W40 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(191, 'TOTAL HI-PERF 4T RACING 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(192, 'TOTAL RUBIA C40 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(193, 'TOTAL RUBIA C40 1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(194, 'TOTAL RUBIA C40 18LP', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(195, 'TOTAL RUBIA S40 18LP', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(196, 'TOTAL RUBIA TIR 7400 15W40 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(197, 'TOTAL RUBIA TIR 15W40 GLN', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(198, 'TOTAL RUBIA TIR 15W40 PL', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(199, 'TOTAL RUBIA XT 15W40 18X1L', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(200, 'TOTAL RUBIA XT 15W40 GLN', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active'),
(201, 'TOTAL RUBIA XT 15W40 PL', NULL, 6, 1, NULL, 0, 5, 0.00, '2025-04-21 23:54:45', '2025-04-21 23:54:45', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--

CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL,
  `sales_record_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_sold` int(11) NOT NULL,
  `unit_price_at_sale` decimal(10,2) NOT NULL,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_records`
--

CREATE TABLE `sales_records` (
  `id` int(11) NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `staff_user_id` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `approved_by_user_id` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_entries`
--

CREATE TABLE `stock_entries` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity_added` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) NOT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Logs additions of stock quantities to products';

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `contact_number`, `email`, `address`, `status`, `created_at`, `updated_at`) VALUES
(6, 'PUREGOLD', NULL, '+1 (239) 187-2371', 'cadydisife@mailinator.com', 'Quis reprehenderit', 'active', '2025-04-17 21:35:33', NULL),
(7, 'ACC MOTORPARTS', NULL, '+12391872371', 'cadydisife@mailinator.com', 'sample address', 'active', '2025-04-18 10:56:39', '2025-04-21 23:23:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'staff',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `last_login_attempt` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `role`, `status`, `created_at`, `last_login`, `login_attempts`, `last_login_attempt`) VALUES
(1, 'admin', '$2y$10$3vzuOJuLrF84lDzjoq4BbOzaAYmFWgwXkzGX4aXFOYqxYhYIZ.G5y', 'Administrator', 'admin', 'active', '2025-04-17 09:33:29', '2025-04-21 17:09:26', 0, NULL),
(2, 'staff1', '$2y$10$poEhheMnb.itIu1Gd.G/Iu8rtclLCdX4h2EpgFs6x33BObsvIOMzW', '', 'staff', 'active', '2025-04-17 09:54:59', '2025-04-21 17:06:30', 0, NULL),
(3, 'staff2', '$2y$10$lcQP/gNFMG.Ouumc88we2.EUCg/zxBbr0fOwn1XUNj/T3.UF85l.e', '', 'staff', 'active', '2025-04-17 09:55:23', NULL, 0, NULL),
(4, 'staff3', '$2y$10$G1MhEsswU1xDELMQlShpdOwPKbGTVRGxH6yZeQGo0T1lyeppaLmRS', '', 'staff', 'active', '2025-04-17 09:55:42', NULL, 0, NULL),
(5, 'staff4', '$2y$10$mj9o5qihdQbtI2Vuiv3oou.vUSVkHxUoucJ1JFIDJJVB6x9P8udl.', '', 'staff', 'inactive', '2025-04-18 09:29:59', '2025-04-18 09:30:11', 0, NULL),
(7, 'owner', '$2y$10$2c0rCG/KEQJokpgLqBfH4u4bagZdLnhZkkE45Nqdab4vGAeTxkMkW', '', 'staff', 'active', '2025-04-19 08:59:34', '2025-04-21 16:26:07', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_log_user` (`user_id`),
  ADD KEY `idx_log_timestamp` (`timestamp`),
  ADD KEY `idx_log_entity` (`entity_type`,`entity_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `idx_category_name` (`name`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `idx_product_name` (`name`),
  ADD KEY `idx_product_category` (`category_id`),
  ADD KEY `idx_product_supplier` (`supplier_id`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_record_id` (`sales_record_id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `sales_records`
--
ALTER TABLE `sales_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_user_id` (`staff_user_id`),
  ADD KEY `approved_by_user_id` (`approved_by_user_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `stock_entries`
--
ALTER TABLE `stock_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_stock_product_id` (`product_id`),
  ADD KEY `idx_stock_user_id` (`user_id`),
  ADD KEY `idx_stock_entry_date` (`entry_date`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_supplier_name` (`name`),
  ADD KEY `idx_supplier_status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_records`
--
ALTER TABLE `sales_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock_entries`
--
ALTER TABLE `stock_entries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sales_record_id`) REFERENCES `sales_records` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `sales_records`
--
ALTER TABLE `sales_records`
  ADD CONSTRAINT `sales_records_ibfk_1` FOREIGN KEY (`staff_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `sales_records_ibfk_2` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `stock_entries`
--
ALTER TABLE `stock_entries`
  ADD CONSTRAINT `fk_stock_entry_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_stock_entry_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
