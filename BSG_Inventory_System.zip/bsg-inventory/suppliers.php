<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) { // Only check if logged in
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}


require_once 'config/database.php';
require_once 'includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "SELECT * FROM suppliers WHERE 1=1";

$params = [];

if ($search) {
    $query .= " AND (name LIKE :search OR contact_number LIKE :search)";
    $params[':search'] = "%$search%";
}

$query .= " ORDER BY name ASC";

try {
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching suppliers: " . $e->getMessage());
    $fetch_error = "Could not retrieve supplier data.";
    $suppliers = [];
}
?>

<div class="container px-6 py-8 mx-auto">


    <?php if (isset($_GET['success']) && $_GET['success'] === 'deleted'): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
            Supplier has been successfully deleted.
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['error']) {
                'supplier-not-found' => 'Supplier not found.',
                'constraint' => 'Cannot delete supplier because they are referenced by other records.',
                'delete-failed' => 'Failed to delete supplier. Please try again.',
                default => 'An error occurred.'
            }) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($fetch_error)): ?>
        <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
            <?= htmlspecialchars($fetch_error) ?>
        </div>
    <?php endif; ?>

    <div class="p-4 mb-6 bg-white rounded-lg shadow">
        <form method="GET" action="suppliers.php" class="flex flex-wrap items-end gap-4">
            <div class="flex-grow">
                <label for="search" class="block mb-1 text-sm font-medium text-gray-700">Search</label>
                <div class="relative">
                    <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>"
                        class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Search by Name">
                    <button type="submit" class="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-600 hover:text-blue-600 transition-colors">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>

           
            <a href="suppliers.php" class="px-4 py-2 text-sm text-gray-700 transition-colors bg-gray-200 rounded-md hover:bg-gray-300">
                <i class="mr-1 fas fa-sync"></i> Reset
            </a>

          <?php if ($_SESSION['role'] === 'admin'): ?>
    <a href="add-supplier.php" class="px-4 py-2 ml-auto text-sm font-medium text-white transition duration-150 ease-in-out bg-blue-600 rounded-md hover:bg-blue-700">
        <i class="mr-2 fas fa-plus"></i>Add Supplier
    </a>
<?php endif; ?>

        </form>
    </div>

    <div class="overflow-hidden bg-white rounded-lg shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                <thead class="text-xs text-white uppercase bg-[#0078b6]">
                    <tr>
                        <th scope="col" class="px-6 py-3 font-semibold">ID</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Name</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Contact Number</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Address</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Status</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($suppliers)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">No suppliers found matching your criteria.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($suppliers as $supplier): ?>
                            <tr class="transition-colors bg-white border-b hover:bg-gray-50">
                                <td class="px-6 py-4 font-medium"><?= htmlspecialchars($supplier['id']) ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"><?= htmlspecialchars($supplier['name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($supplier['contact_number']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($supplier['address']) ?></td>
                                <td class="px-6 py-4 text-center">
                                    <span class="px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap <?= $supplier['status'] === 'active' ? 'bg-green-100 text-green-800 border border-green-200' : 'bg-red-100 text-red-800 border border-red-200' ?>">
                                        <?= ucfirst($supplier['status'] ?? 'Unknown') ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
    <div class="flex justify-center space-x-2">
        <a href="view-supplier.php?id=<?= $supplier['id'] ?>"
           class="p-1.5 text-blue-600 bg-blue-100 rounded-full hover:bg-blue-200 transition-colors" title="View Details">
            <i class="fas fa-eye"></i>
        </a>
        <?php if ($_SESSION['role'] === 'admin'): // Admin Only Actions ?>
            <a href="edit-supplier.php?id=<?= $supplier['id'] ?>"
               class="p-1.5 text-green-600 bg-green-100 rounded-full hover:bg-green-200 transition-colors" title="Edit Supplier">
                <i class="fas fa-edit"></i>
            </a>
            <form class="inline" method="POST" action="delete-supplier.php"
                  onsubmit="return confirm('Are you sure you want to delete this supplier? This action cannot be undone.');">
                <input type="hidden" name="id" value="<?= $supplier['id'] ?>">
                <button type="submit" class="p-1.5 text-red-600 bg-red-100 rounded-full hover:bg-red-200 transition-colors" title="Delete Supplier">
                    <i class="fas fa-trash"></i>
                </button>
            </form>
        <?php endif; // End Admin Only Actions ?>
    </div>
</td>

                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>