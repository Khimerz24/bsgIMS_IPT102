<?php

// --- Role Check (must occur before any output) ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Include Database Config Only ---
require_once 'config/database.php';

// --- Initialize error variable ---
$error = '';

// --- Handle Form Submission (must occur before any output) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $stmt = $pdo->prepare(
            "INSERT INTO suppliers (name, contact_number, address, email, status, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())"
        );
        $stmt->execute([
            $_POST['name'],
            $_POST['contact_number'],
            $_POST['address'],
            $_POST['email'],
            $_POST['status']
        ]);

        header('Location: suppliers.php?success=added');
        exit();
    } catch (PDOException $e) {
        $error = "Error adding supplier: " . $e->getMessage();
    }
}

// --- Include Header After Logic ---
require_once 'includes/header.php';
?>

<div class="p-6">
    <div class="max-w-3xl mx-auto bg-white rounded-lg shadow-lg">
        <div class="p-4 rounded-t-lg bg-primary-light">
            <h2 class="text-2xl font-bold text-gray-800">Add New Supplier</h2>
        </div>

        <?php if (!empty($error)): ?>
            <div class="px-4 py-3 mb-4 text-red-700 bg-red-100 border border-red-400 rounded">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="p-6 space-y-6 rounded-b-lg bg-gray-50">
            <div class="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="name">Supplier Name</label>
                    <input id="name" type="text" name="name" placeholder="e.g., Tech Corp" required 
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="contact_number">Contact Number</label>
                    <input id="contact_number" type="tel" name="contact_number" placeholder="e.g., 0912-345-6789" required 
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"
                           pattern="[0-9\+\-\(\) ]{10,20}">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="email">Email</label>
                    <input id="email" type="email" name="email" placeholder="example@gmail.com (Optional)" 
                           class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ringOopacity-50">
                </div>

                <div>
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="status">Status</label>
                    <select id="status" name="status" required 
                            class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ringOopacity-50">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>

                <div class="col-span-full">
                    <label class="block mb-1 text-lg font-semibold text-gray-900" for="address">Address</label>
                    <textarea id="address" name="address" rows="4" placeholder="Street, Baranggay, City, ... (Optional)" 
                              class="block w-full px-4 py-2 text-lg bg-white border-2 border-gray-300 rounded-lg shadow focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"></textarea>
                </div>
            </div>

            <div class="flex flex-col justify-end space-y-3 md:flex-row md:space-y-0 md:space-x-4">
                <a href="suppliers.php" 
                   class="px-6 py-3 text-lg font-medium text-center text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">Cancel</a>
                <button type="submit" 
                        class="px-6 py-3 text-lg font-semibold text-white rounded-lg bg-royal-blue hover:bg-blue-700">Add Supplier</button>
            </div>
        </form>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
