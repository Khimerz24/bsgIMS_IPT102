<?php

// Session security configuration must come BEFORE session_start()
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
// Set secure flag only if using HTTPS
// ini_set('session.cookie_secure', 1);

session_start();
session_regenerate_id(true);

require_once 'config/database.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Username and password are required.';
    } else {
        try {
            // --- MODIFIED LOGIC ---

            // 1. Fetch user by username ONLY (ignore status for now)
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user) {
                // 2. User found, NOW check their status
                if ($user['status'] === 'inactive') {
                    // Specific error for inactive accounts
                    $error = 'This account is disabled. Please contact the administrator.';
                    error_log("Login attempt for disabled account: " . $username); // Optional: Log this specific case
                }
                // 3. Status is NOT inactive (must be 'active'), verify password
                elseif (password_verify($password, $user['password'])) {
                    // --- Login Success Logic ---
                    session_regenerate_id(true); // Regenerate session ID for security
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];

                    // Update last login time
                    $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $updateStmt->execute([$user['id']]);

                    header('Location: dashboard.php');
                    exit();
                    // --- End Login Success Logic ---
                }
                // 4. Status is active, but password failed
                else {
                    $error = 'Invalid username or password.';
                    error_log("Login failed (wrong password) for username: " . $username);
                }
            }
            // 5. User not found by username
            else {
                $error = 'Invalid username or password.';
                error_log("Login failed (user not found): " . $username);
            }
            // --- END OF MODIFIED LOGIC ---
        } catch (PDOException $e) {
            error_log("Database error during login: " . $e->getMessage());
            $error = "System error during login. Please try again later.";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BSG Fuel & Services Corporation - Login</title>
    <!-- Icon on the top of the tab -->
    <link rel="icon" href="assets/img/BSG_favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="assets/img/BSG_favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4169E1;
            --secondary-color: #f2f5ff; 
            --text-color: #2c3afb;
            --primary-color2: #839deb;
            --white-color: #ffffff;
            --error-bg: rgba(255, 0, 0, 0.1);
            --error-text: #dc3545;
            --input-border: #ced4da;
            --input-focus-border: #86b7fe;
            --text-muted: #6c757d;
        }
        * { margin:0; padding:0; box-sizing:border-box; font-family:Tahoma,sans-serif; }
        body { background-color:var(--secondary-color); display:flex; justify-content:center; align-items:center; min-height:100vh; padding:20px; }
        .container { width:100%; max-width:1200px; background:var(--white-color); border-radius:8px; overflow:hidden; display:flex; flex-direction:column; }
        @media(min-width:992px){ .container{ flex-direction:row; height:750px;} }
        .left-panel, .right-panel { flex:1; display:flex; flex-direction:column; justify-content:center; align-items:center; padding:40px; }
        .left-panel { background:var(--white-color);} .right-panel { background:var(--primary-color);}        
        .logo-container { width:400px; margin-bottom:30px; }
        .logo { width:100%; height:auto; }
        .company-name { text-align: center; text-shadow: 4px 4px 4px rgba(0, 0, 0, 0.25);}
        .company-name h1 { font-size:clamp(2.5rem,6vw,3.5rem); color:var(--text-color); font-weight:bold; }
        .company-name h2 { font-size:clamp(1.2rem,4vw,1.75rem); color:var(--text-color);  }
        .login-form-container { width:100%; max-width:400px; background:var(--primary-color2); padding:30px; border-radius:10px; box-shadow:0 4px 8px rgba(0,0,0,0.1); }
        .login-form-container h2 { text-align:center; color:var(--white-color); text-shadow:1px 1px 3px rgba(0,0,0,0.2); font-size:clamp(1.5rem,5vw,2rem); margin-bottom:40px; font-weight:bold; }
        .form-group { position:relative; margin-bottom:25px; }
        .form-group .icon { position:absolute; top:50%; left:12px; transform:translateY(-50%); color:var(--text-muted); pointer-events:none; font-size:1.1rem; }
        .input-field { width:100%; padding:12px 12px 12px 40px; border:1px solid var(--input-border); border-radius:5px; font-size:1rem; transition:border-color .15s,box-shadow .15s; }
        .input-field:focus { border-color:var(--input-focus-border); outline:0; box-shadow:0 0 0 0.2rem rgba(134,183,254,0.25); }
        .error-message { color:var(--error-text); background:var(--error-bg); border:1px solid var(--error-text); padding:12px; border-radius:5px; margin-bottom:20px; text-align:center; font-size:0.9rem; }
        .btn { width:100%; padding:15px; background:var(--text-color); color:var(--white-color); border:none; border-radius:5px; font-size:1.1rem; font-weight:bold; cursor:pointer; margin-top:10px; transition:background-color .2s; }
        .btn:hover { background:#112673; }
        .forgot-password { margin-bottom:20px; }
        .forgot-password a { color:var(--white-color); text-decoration:none; font-size:0.9rem; }
        .forgot-password a:hover { text-decoration:underline; }
        .show-password-toggle { position:absolute; top:50%; right:12px; transform:translateY(-50%); cursor:pointer; color:var(--text-muted); font-size:1.2rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="logo-container"><img src="assets/img/BSG_LOGO.svg" alt="BSG Logo" class="logo"></div>
            <div class="company-name"><h1>BSG</h1><h2>Fuel & Services Corporation</h2></div>
        </div>
        <div class="right-panel">
            <div class="login-form-container">
                <h2>LOGIN</h2>
                <?php if ($error): ?><div class="error-message"><?= htmlspecialchars($error) ?></div><?php endif; ?>
                <form method="POST" action="login.php">
                    <div class="form-group">
                        <i class="icon ri-user-line"></i>
                        <input type="text" name="username" class="input-field" placeholder="Username" required value="<?= htmlspecialchars($username) ?>">
                    </div>
                    <div class="form-group">
                        <i class="icon ri-lock-line"></i>
                        <input type="password" id="password-field" name="password" class="input-field" placeholder="Password" required>
                        <i class="ri-eye-line show-password-toggle" id="togglePassword"></i>
                    </div>
                    <button type="submit" class="btn">Login</button>
                </form>
            </div>
        </div>
    </div>
    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const passwordField = document.querySelector('#password-field');
        togglePassword.addEventListener('click', function () {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            this.classList.toggle('ri-eye-line');
            this.classList.toggle('ri-eye-off-line');
        });
    </script>
</body>
</html>