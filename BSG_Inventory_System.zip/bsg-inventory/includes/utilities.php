<?php
function formatCurrency($amount) {
    return '₱' . number_format($amount, 2);
}

function getStatusBadge($status) {
    $badges = [
        'low_stock' => 'bg-red-100 text-red-800',
        'in_stock' => 'bg-green-100 text-green-800',
        'out_of_stock' => 'bg-gray-100 text-gray-800'
    ];
    
    return $badges[$status] ?? 'bg-gray-100 text-gray-800';
}