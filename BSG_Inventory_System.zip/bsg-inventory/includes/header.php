<?php
// Session start logic...
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Login check logic...
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get user role and CORRECTLY get username
$user_role = $_SESSION['role'] ?? 'user';
// **** CORRECTED LINE ****
$user_name = $_SESSION['username'] ?? 'User'; // Use username (lowercase n) set during login
// **** END CORRECTED LINE ****


// --- Fetch Pending Sales Count for Admin Notification ---

$pending_sales_count = 0;

if ($user_role === 'admin') {

    try {

        require_once __DIR__ . '/../config/database.php'; // Use absolute path from current file

        $stmt = $pdo->query("SELECT COUNT(*) FROM sales_records WHERE status = 'pending'");

        $pending_sales_count = (int)$stmt->fetchColumn();

    } catch (PDOException $e) {

        error_log("Error fetching pending sales count for header: " . $e->getMessage());

        // Don't break the page, just won't show notification count accurately

        $pending_sales_count = 0; // Default to 0 on error

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>BSG Inventory System</title>

    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Icon on the top of the tab -->
    <link rel="icon" href="assets/img/BSG_favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="assets/img/BSG_favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.5.0/fonts/remixicon.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />

    <script>

        tailwind.config = {

            theme: {

                extend: {

                    colors: {

                        'royal-blue': '#4169E1',

                        'primary': '#4169E1', // Added for consistency if used elsewhere

                        'primary-dark': '#3557B8', // Darker shade for hover

                    },

                },

            },

        }

    </script>

    <link rel="stylesheet" href="assets/css/style.css"> <!-- Optional: Link to your custom CSS -->

    <!-- Add Alpine.js for simple interactions -->

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>

        /* Add styles for Alpine.js transitions if needed */

        [x-cloak] { display: none !important; }

        

        /* Make the sidebar extend to the bottom of the page */

        body {

            display: flex;

            flex-direction: column;

            min-height: 100vh;

        }

        

        .main-wrapper {

            display: flex;

            flex: 1;

        }

        

        .sidebar {

            position: sticky;

            top: 0;

            height: 100vh;

            z-index: 40;

        }

        

        .content-wrapper {

            display: flex;

            flex-direction: column;

            flex: 1;

        }

        

        footer {

            background-color: white;

            padding: 1rem;

            text-align: center;

            border-top: 1px solid #e5e7eb;

        }

          /* Table header styling */

        .table-header {

            background-color: #0078b6;

            color: white;

        }

        

        /* For any existing bg-gray-50 or bg-gray-100 classes that might be used for table headers */

        .table-header th {

            font-weight: 600;

        }

    </style>

</head>

<body>

    <div class="main-wrapper">

        <!-- Sidebar -->

        <div class="w-64 overflow-y-auto shadow-lg sidebar bg-royal-blue">

            <!-- Logo section -->

            <div class="flex items-center justify-center p-2 border-b border-white/20">

                <a href="dashboard.php" class="flex items-center justify-center"> <!-- Make logo clickable -->

                    <img src="assets/img/BSG_ICON.png" alt="BSG Logo" class="w-auto h-30">

                </a>

            </div>



            <!-- Navigation -->
        <!-- Sidebar Links -->
        <nav class="mt-10">
            <a href="dashboard.php" class="flex items-center px-4 py-2 mt-5 text-gray-100 hover:bg-gray-700 <?= ($current_page == 'dashboard.php') ? 'bg-gray-700' : '' ?>">
                <i class="mr-3 fas fa-tachometer-alt"></i> Dashboard
            </a>

            <?php // *** CHANGE THIS PART ***
            // Show Products and Suppliers to both Admin and Staff
            if (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'staff')): ?>
                <a href="products.php" class="flex items-center px-4 py-2 mt-5 text-gray-100 hover:bg-gray-700 <?= ($current_page == 'products.php' || $current_page == 'edit-product.php' || $current_page == 'add-product.php' || $current_page == 'view-product.php' || $current_page == 'add-stock.php') ? 'bg-gray-700' : '' ?>">
                    <i class="mr-3 fas fa-box"></i> Products
                </a>
                <a href="suppliers.php" class="flex items-center px-4 py-2 mt-5 text-gray-100 hover:bg-gray-700 <?= ($current_page == 'suppliers.php' || $current_page == 'edit-supplier.php' || $current_page == 'add-supplier.php' || $current_page == 'view-supplier.php') ? 'bg-gray-700' : '' ?>">
                     <i class="mr-3 fas fa-truck group-hover:text-white"></i> Suppliers
                </a>
            <?php endif; ?>

            <?php // Sales: Visible to both Admin and Staff (Assuming this is already the case) ?>
            <a href="sales.php" class="flex items-center px-4 py-2 mt-5 text-gray-100 hover:bg-gray-700 <?= ($current_page == 'sales.php' || $current_page == 'add-sale.php' || $current_page == 'view-sale.php') ? 'bg-gray-700' : '' ?>">
                <i class="mr-3 fas fa-cash-register"></i> Sales
            </a>

            <?php // Staff Management: Admin Only (Keep this as is) ?>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <a href="staff.php" class="flex items-center px-4 py-2 mt-5 text-gray-100 hover:bg-gray-700 <?= ($current_page == 'staff.php' || $current_page == 'add-staff.php' || $current_page == 'edit-staff.php') ? 'bg-gray-700' : '' ?>">
                    <i class="mr-3 fas fa-users-cog"></i> Staff Management
                </a>
            <?php endif; ?>

            <!-- Other links -->
        </nav>




            <!-- Logout Button at the bottom -->

            <div class="absolute bottom-0 w-full p-4 border-t border-white/20">

                <a href="logout.php" class="flex items-center w-full px-4 py-3 text-red-300 rounded-md hover:bg-red-700 hover:text-white group">

                    <i class="w-6 text-lg text-center fas fa-sign-out-alt group-hover:text-white"></i>

                    <span class="ml-3 text-base">Logout</span>

                </a>

            </div>

        </div> <!-- End Sidebar -->



        <!-- Content Wrapper -->

        <div class="content-wrapper">

            <!-- Top header -->

            <header class="sticky top-0 z-20 bg-white shadow-sm">

                <div class="flex items-center justify-between h-16 px-6">

                    <!-- Hamburger Menu for Mobile (Still needed) -->

                    <button class="text-gray-600 lg:hidden focus:outline-none" id="sidebar-toggle">

                        <i class="fas fa-bars fa-lg"></i>

                    </button>



                    <h1 class="text-3xl font-semibold text-gray-800" id="page-title">

                        <?php

                        // Dynamically set page title based on the current script

                        $current_page = basename($_SERVER['PHP_SELF']);

                        $page_titles = [

                            'dashboard.php' => 'Dashboard',

                            'suppliers.php' => 'Suppliers',

                            'add-supplier.php' => 'Add Supplier',

                            'edit-supplier.php' => 'Edit Supplier',

                            'view-supplier.php' => 'Supplier Details',

                            'products.php' => 'Products',

                            'add-product.php' => 'Add Product',

                            'edit-product.php' => 'Edit Product',

                            'view-product.php' => 'Product Details',

                            'staff.php' => 'Account Management',

                            'add-staff.php' => 'Add Staff Member',

                            'edit-staff.php' => 'Edit Staff Member',

                            'sales.php' => 'Sales Records',

                            'add-sale.php' => 'Record New Sale',

                            'view-sale.php' => 'Sale Details',

                        ];

                        echo $page_titles[$current_page] ?? 'Inventory System'; // Default title

                        ?>
                    
                    
                    </h1>

                    <div class="flex items-center space-x-4">
<p class="text-sm text-left text-gray-500"><?= date('l, F j, Y') ?></p>
                        <!-- Notifications (Admin Only & if pending sales exist) -->

                        <?php if ($user_role === 'admin' && $pending_sales_count > 0): ?>

                        <div class="relative">

                            <a href="sales.php?status=pending" class="p-2 text-gray-600 rounded-full hover:bg-gray-100 hover:text-primary focus:outline-none" title="<?= $pending_sales_count ?> Pending Sales">

                                <i class="fas fa-bell"></i>

                                <!-- Notification badge -->

                                <span class="absolute top-0 right-0 block w-2 h-2 transform translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full ring-2 ring-white"></span>

                            </a>

                        </div>

                        <?php endif; ?>
                    <!-- User Info Dropdown -->

                                       <!-- User Info Dropdown -->
                  <!-- User Info Dropdown -->
            <div x-data="{ open: false }" class="relative">
                <button @click="open = !open" class="flex items-center space-x-2 text-gray-600 hover:text-primary focus:outline-none">
                    <i class="fas fa-user-circle fa-lg"></i>
                    <!-- This line was already correct, it uses the $user_name variable -->
                    <span class="text-sm font-medium"><?= htmlspecialchars($user_name) ?></span>
                    <i class="fas fa-chevron-down fa-xs"></i>
                </button>


                        <div x-show="open" @click.away="open = false" x-cloak class="absolute right-0 w-48 mt-2 bg-white border rounded-md shadow-lg">

                            <div class="px-4 py-2 text-gray-800 border-b">

                                Logged in as <strong><?= htmlspecialchars($user_role) ?></strong>

                            </div>

                            <a href="logout.php" class="block px-4 py-2 text-red-600 hover:bg-gray-100">Logout</a>

                        </div>

                    </div>

                </div>

            </div>

        </header>



        <!-- Main Content goes here -->
