<?php
// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins to the dashboard with an error message
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the page code starts here ---
require_once 'config/database.php'; // If needed by this specific page
// require_once 'includes/header.php'; // This will be included AFTER the check if it's a display page

// --- Authorization Check ---
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php'); // Redirect unauthorized users
    exit();
}

$admin_user_id = $_SESSION['user_id'];

// --- Validate Request ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['sales_record_id']) || !is_numeric($_POST['sales_record_id'])) {
    header('Location: sales.php?error=invalid_request');
    exit();
}

$sales_record_id = (int)$_POST['sales_record_id'];
$rejection_reason = isset($_POST['rejection_reason']) ? trim($_POST['rejection_reason']) : null;
if (empty($rejection_reason)) { // Treat empty string as NULL
    $rejection_reason = null;
}

// --- Process Rejection ---
try {
    // 1. Fetch the sales record and verify it's 'pending'
    $stmt = $pdo->prepare("SELECT id, status FROM sales_records WHERE id = ?");
    $stmt->execute([$sales_record_id]);
    $sale_record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sale_record) {
        throw new Exception("Sale record not found.", 404);
    }
    if ($sale_record['status'] !== 'pending') {
        throw new Exception("Sale is not pending and cannot be rejected.", 400);
    }

    // 2. Update Sales Record Status
    $updateSaleStmt = $pdo->prepare("
        UPDATE sales_records
        SET status = 'rejected', approved_by_user_id = ?, approved_at = NOW(), rejection_reason = ?
        WHERE id = ? AND status = 'pending' -- Ensure status hasn't changed
    ");
    $updateSaleStmt->execute([$admin_user_id, $rejection_reason, $sales_record_id]);

    if ($updateSaleStmt->rowCount() === 0) {
         throw new Exception("Failed to update sale record status or status was already changed.", 409);
    }

    header('Location: sales.php?success=rejected');
    exit();

} catch (Exception $e) {
    error_log("Error rejecting sale (ID: $sales_record_id): " . $e->getMessage());

    $error_code = 'reject_failed';
     if ($e->getCode() === 404) {
        $error_code = 'not_found';
    } elseif ($e->getCode() === 400 || $e->getCode() === 409) {
         $error_code = 'invalid_status';
    }

    header('Location: view-sale.php?id=' . $sales_record_id . '&error=' . $error_code); // Redirect back to detail view with error
    exit();
}
?>
