<?php
// Redirect to the login page
header('Location: login.php');
exit(); // Ensure no further code is executed after the redirect
?>
