<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


if (!isset($_SESSION['user_id'])) { // Only check if logged in
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}


require_once 'config/database.php';


$supplier_id = null;
$supplier = null;
$fetch_error = null;

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: suppliers.php?error=invalid_request');
    exit();
}
$supplier_id = (int)$_GET['id'];

try {
    $stmt = $pdo->prepare("SELECT * FROM suppliers WHERE id = ?");
    $stmt->execute([$supplier_id]);
    $supplier = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$supplier) {
        header('Location: suppliers.php?error=not_found');
        exit();
    }
} catch (PDOException $e) {
    error_log("Error fetching supplier (ID: $supplier_id): " . $e->getMessage());
    $fetch_error = "Could not load supplier data.";
}

require_once 'includes/header.php';
?>

<div class="container px-4 py-6 mx-auto">
    <div class="max-w-3xl p-6 mx-auto bg-white rounded-lg shadow">

        <?php if ($fetch_error): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($fetch_error) ?>
                <p class="mt-2"><a href="suppliers.php" class="font-semibold underline hover:text-red-900">Return to Suppliers List</a></p>
            </div>
        <?php elseif ($supplier): ?>
           <div class="flex flex-col items-start justify-between gap-4 pb-4 mb-6 border-b sm:flex-row sm:items-center">
    <h1 class="text-2xl font-semibold text-gray-800">Supplier Details</h1>
    <div class="flex space-x-2">
        <?php if ($_SESSION['role'] === 'admin'): ?>
            <a href="edit-supplier.php?id=<?= $supplier['id'] ?>"
               class="px-4 py-2 text-sm font-medium text-white transition duration-150 ease-in-out rounded-md bg-royal-blue hover:bg-primary-dark">
                <i class="mr-1 fas fa-edit"></i> Edit
            </a>
        <?php endif; ?>
        <a href="suppliers.php"
           class="px-4 py-2 text-sm font-medium text-gray-700 transition duration-150 ease-in-out bg-gray-200 rounded-md hover:bg-gray-300" title="Back">
             <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>
</div>


            <div class="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">
                <div>
                    <label class="block text-sm font-medium text-gray-500">Supplier Name</label>
                    <p class="mt-1 text-gray-900"><?= htmlspecialchars($supplier['name']) ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-500">Contact Person</label>
                    <p class="mt-1 text-gray-900"><?= htmlspecialchars($supplier['contact_person'] ?? 'N/A') ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-500">Email</label>
                    <p class="mt-1 text-gray-900"><?= htmlspecialchars($supplier['email'] ?? 'N/A') ?></p>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-500">Phone</label>
                    <p class="mt-1 text-gray-900"><?= htmlspecialchars($supplier['phone'] ?? 'N/A') ?></p>
                </div>
                 <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-500">Address</label>
                    <p class="mt-1 text-gray-900"><?= nl2br(htmlspecialchars($supplier['address'] ?? 'N/A')) ?></p>
                    
                </div>
                 <div>
                    <label class="block text-sm font-medium text-gray-500">Status</label>
                    <p class="mt-1">
                        <span class="px-2.5 py-0.5 text-xs font-medium rounded-full <?= $supplier['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                            <?= ucfirst($supplier['status']) ?>
                        </span>
                    </p>
                </div>
                 
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>