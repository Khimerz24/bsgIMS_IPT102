<?php
// --- SET DEFAULT TIMEZONE (MODIFIED) ---
// --- Role Check (MUST BE FIRST before any output) ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Check if user is logged in AND is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // User is not an admin or not logged in, show 404 Not Found
    http_response_code(404); // Set HTTP status code to 404

    // Optional: Include a dedicated 404 error page if you have one
    // include 'includes/404.php';

    // Or just output a simple 404 message directly
    echo "<!DOCTYPE html>";
    echo "<html lang='en'>";
    echo "<head><meta charset='UTF-8'><title>404 Not Found</title>";
    echo "<style>body { font-family: sans-serif; padding: 20px; text-align: center; } h1 { color: #dc3545; } </style>";
    echo "</head>";
    echo "<body>";
    echo "<h1>404 Not Found</h1>";
    echo "<p>The page you requested could not be found.</p>";
    echo "<p><a href='dashboard.php'>Go to Dashboard</a></p>"; // Link back to safety
    echo "</body>";
    echo "</html>";

    exit(); // Stop script execution immediately
}

// --- If the script reaches here, the user IS an admin ---

// --- Now include header and the rest of the page logic ---
require_once 'includes/header.php';
require_once 'config/database.php';

// --- Fetch Staff Data ---
try {
        // Fetch original last_login AND a version converted to Asia/Manila by MySQL
    // Assuming the source timezone ('SYSTEM') is effectively UTC on Namecheap
    $sql = "SELECT id, username, role, status, created_at, last_login,
                   CONVERT_TZ(last_login, 'UTC', 'Asia/Manila') as last_login_pht
            FROM users
            ORDER BY username ASC";
    $stmt = $pdo->query($sql);

    $staff_members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching staff: " . $e->getMessage());
    // Display a user-friendly error message (optional)
    $fetch_error = "Could not retrieve staff data. Please try again later.";
    $staff_members = []; // Ensure $staff_members is an array
}

// --- Helper Function for Time Ago ---
function time_ago($timestamp) {
    if ($timestamp === null) {
        return 'Never';
    }
    try {
        // Define the timezone we EXPECT the database timestamp string to represent
        $databaseTimezone = new DateTimeZone('Asia/Manila');

        // Define the timezone for 'now' (should match the expected database timezone for correct comparison)
        $currentTimezone = new DateTimeZone('Asia/Manila');

        // Create DateTime object for the database timestamp, explicitly interpreting the string as Asia/Manila
        $time_ago_dt = new DateTime($timestamp, $databaseTimezone);

        // Create DateTime object for the current time, explicitly in Asia/Manila
        $current_time_dt = new DateTime('now', $currentTimezone);

        // Calculate the difference in seconds using Unix timestamps (which are always UTC based)
        // This is the most reliable way to get the actual elapsed time
        $time_difference = $current_time_dt->getTimestamp() - $time_ago_dt->getTimestamp();

        // Handle cases where the timestamp might be slightly in the future
        if ($time_difference < 0) {
             if ($time_difference >= -10) { // Allow slightly larger margin (10s)
                 return "Just Now";
             }
             error_log("time_ago: Calculated time difference is negative ($time_difference seconds) for timestamp '$timestamp'. Check server clocks/timezones.");
             return 'Sync Error'; // Indicate potential issue
        }

        // --- Existing calculation logic based on seconds ---
        $seconds = $time_difference;
        $minutes = round($seconds / 60);
        $hours = round($seconds / 3600);
        $days = round($seconds / 86400);
        $weeks = round($seconds / 604800);
        $months = round($seconds / 2629440);
        $years = round($seconds / 31553280);

        if ($seconds <= 60) return "Just Now";
        else if ($minutes <= 60) return ($minutes == 1) ? "1 minute ago" : "$minutes minutes ago";
        else if ($hours <= 24) return ($hours == 1) ? "1 hour ago" : "$hours hours ago";
        else if ($days <= 7) return ($days == 1) ? "Yesterday" : "$days days ago";
        else if ($weeks <= 4.3) return ($weeks == 1) ? "A week ago" : "$weeks weeks ago";
        else if ($months <= 12) return ($months == 1) ? "A month ago" : "$months months ago";
        else return ($years == 1) ? "One year ago" : "$years years ago";
        // --- End of existing calculation logic ---

    } catch (Exception $e) {
        error_log("Error in time_ago function for timestamp '$timestamp': " . $e->getMessage());
        return 'Invalid date';
    }
}

?>
<div class="container px-4 py-6 mx-auto">

    <!-- Page Title and Add Button -->
    <div class="flex flex-col items-center justify-between gap-4 mb-6 sm:flex-row">
        <h1 class="text-2xl font-semibold text-gray-800">Manage Staff</h1> <!-- Added a title -->
        <a href="add-staff.php" class="px-5 py-2 text-white transition duration-150 ease-in-out rounded-md bg-royal-blue hover:bg-primary-dark">
            <i class="mr-2 fas fa-plus"></i>Add New Staff
        </a>
    </div>

    <!-- Success/Error Messages -->
    <?php if (isset($_GET['success'])): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['success']) {
                'added' => 'Staff member added successfully.',
                'updated' => 'Staff member updated successfully.',
                'status_changed' => 'Staff member status changed successfully.',
                default => 'Operation successful.'
            }) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
         <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
             <?= htmlspecialchars(match($_GET['error']) {
                 'not_found' => 'Staff member not found.',
                 'update_failed' => 'Failed to update staff member.',
                 'add_failed' => 'Failed to add staff member.',
                 'status_failed' => 'Failed to change staff status.',
                 'self_action' => 'You cannot change your own status or role.', // Updated self_action message slightly
                 'delete_failed' => 'Failed to manage staff member.', // Generic
                 'last_admin' => 'Operation failed: Cannot remove the last active admin account.', // <-- ADD THIS LINE
                 'invalid_request' => 'Invalid request.', // <-- Optional: Add if needed from edit-staff.php
                 'db_error' => 'A database error occurred. Please try again.', // <-- Optional: Add if needed from toggle-staff-status.php
                 default => 'An error occurred.'
             }) ?>
         </div>
    <?php endif; ?>

     <?php if (isset($fetch_error)): ?>
         <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
             <?= htmlspecialchars($fetch_error) ?>
         </div>
     <?php endif; ?>


    <!-- Staff Table -->
    <div class="overflow-hidden bg-white rounded-lg shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                 <thead class="text-xs uppercase table-header">
                    <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Username</th>
                        <th scope="col" class="px-6 py-3">Role</th>
                        <th scope="col" class="px-6 py-3">Status</th>
                        <th scope="col" class="px-6 py-3">Created</th>
                        <th scope="col" class="px-6 py-3">Last Login</th>
                        <th scope="col" class="px-6 py-3 text-center">Actions</th>
                    </tr>
                </thead>
                              <tbody>
                    <?php if (empty($staff_members) && !isset($fetch_error)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="7" class="px-6 py-4 text-center text-gray-500">No staff members found.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($staff_members as $staff): ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                <td class="px-6 py-4"><?= htmlspecialchars($staff['id']) ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900"><?= htmlspecialchars($staff['username']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars(ucfirst($staff['role'])) ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium <?= $staff['status'] === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                        <?= ucfirst($staff['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4"><?= $staff['created_at'] ? date('M d, Y', strtotime($staff['created_at'])) : 'N/A' ?></td>

                                                                <td class="px-6 py-4">
                                    <?php
                                        $last_login_timestamp = $staff['last_login']; // String from DB (should be PHT now)
                                        $display_datetime = 'Never'; // Default display text
                                        $login_style = 'color: gray;'; // Default style (gray text)
                                        $recent_style = 'background-color: #99FF7A; color: #166534;'; // Recent style

                                        if ($last_login_timestamp !== null) {
                                            try {
                                                // --- Format Display String ---
                                                // Convert the string (assumed PHT) to a Unix timestamp
                                                $unix_timestamp = strtotime($last_login_timestamp);
                                                // Format using simple date()
                                                $display_datetime = date('M d, Y h:i A', $unix_timestamp);

                                                // --- Check Recency for Styling ---
                                                // Use DateTime with Asia/Manila for consistency
                                                $phpTimezone = new DateTimeZone('Asia/Manila');
                                                $time_ago_dt = new DateTime($last_login_timestamp, $phpTimezone);
                                                $current_time_dt = new DateTime('now', $phpTimezone);

                                                $time_difference = $current_time_dt->getTimestamp() - $time_ago_dt->getTimestamp();

                                                // Check if login was within the last 24 hours (86400 seconds)
                                                if ($time_difference >= 0 && $time_difference <= 86400) {
                                                    $login_style = $recent_style; // Apply recent style
                                                }

                                            } catch (Exception $e) {
                                                // Log error if DateTime fails
                                                error_log("Error processing last_login timestamp '{$last_login_timestamp}' after SET time_zone: " . $e->getMessage());
                                                $display_datetime = 'Invalid Date';
                                                $login_style = 'color: red;';
                                            }
                                        }
                                    ?>
                                    <!-- Output the span with the determined style and display text -->
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium" style="<?= $login_style ?>">
                                        <?= $display_datetime ?>
                                    </span>
                                </td>


                            

                                <!-- **** END MODIFICATION **** -->

                                <td class="px-6 py-4 text-center whitespace-nowrap">
                                    <!-- Action Buttons (Existing Code) -->
                                    <a href="edit-staff.php?id=<?= $staff['id'] ?>"
                                       class="mr-3 text-indigo-600 hover:text-indigo-900" title="Edit">
                                        <i class="fas fa-edit fa-fw"></i>
                                    </a>
                                    <?php if ($staff['id'] != $_SESSION['user_id']): // Prevent self-deactivation/activation ?>
                                        <form class="inline" method="POST" action="toggle-staff-status.php"
                                              onsubmit="return confirm('Are you sure you want to <?= $staff['status'] === 'active' ? 'deactivate' : 'activate' ?> this user?');">
                                            <input type="hidden" name="id" value="<?= $staff['id'] ?>">
                                            <input type="hidden" name="current_status" value="<?= $staff['status'] ?>">
                                            <button type="submit"
                                                    class="<?= $staff['status'] === 'active' ? 'text-yellow-600 hover:text-yellow-900' : 'text-green-600 hover:text-green-900' ?>"
                                                    title="<?= $staff['status'] === 'active' ? 'Deactivate' : 'Activate' ?>">
                                                <i class="fas <?= $staff['status'] === 'active' ? 'fa-user-slash' : 'fa-user-check' ?> fa-fw"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-gray-400 cursor-not-allowed" title="Cannot change your own status">
                                            <i class="fas fa-user-slash fa-fw"></i>
                                        </span>
                                    <?php endif; ?>
                                    <!-- Optional Delete Button -->
                                </td>
                            </tr>
                        <?php endforeach; ?>
                     <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
