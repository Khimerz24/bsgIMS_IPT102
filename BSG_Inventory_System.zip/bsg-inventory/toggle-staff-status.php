<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config/database.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['id']) || !is_numeric($_POST['id']) || !isset($_POST['current_status'])) {
        header('Location: staff.php?error=invalid_request');
        exit();
    }

    $staff_id = (int)$_POST['id'];
    $current_status = $_POST['current_status'];
    $new_status = ($current_status === 'active') ? 'inactive' : 'active';

    // Prevent self-deactivation
    if ($staff_id === $_SESSION['user_id']) {
        header('Location: staff.php?error=self_action');
        exit();
    }

    try {
        // --- *** NEW CHECK: Prevent deactivating the last active admin *** ---
        $can_proceed = true; // Flag to control execution

        // Only check if the action is DEACTIVATION
        if ($new_status === 'inactive') {
            // First, check if the user being deactivated is currently an admin
            $stmtRole = $pdo->prepare("SELECT role FROM users WHERE id = ?");
            $stmtRole->execute([$staff_id]);
            $user_role = $stmtRole->fetchColumn();

            if ($user_role === 'admin') {
                error_log("Attempting to deactivate an admin (ID: $staff_id). Checking count...");
                // Now, count OTHER active admins
                $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active' AND id != ?");
                $stmtCount->execute([$staff_id]);
                $active_admin_count = $stmtCount->fetchColumn();

                error_log("Count of OTHER active admins: " . $active_admin_count);

                if ($active_admin_count === 0) {
                    error_log("ACTION BLOCKED: Cannot deactivate the last active admin (Staff ID: $staff_id).");
                    $can_proceed = false; // Set flag to prevent update
                    // Redirect with a specific error
                    header('Location: staff.php?error=last_admin');
                    exit();
                } else {
                     error_log("Deactivation allowed: Other active admins exist ($active_admin_count).");
                }
            } else {
                 error_log("Deactivating a non-admin user (ID: $staff_id). Check skipped.");
            }
        }
        // --- *** END NEW CHECK *** ---

        // Proceed only if the flag is still true (last admin check passed or wasn't needed)
        if ($can_proceed) {
            $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ?");
            if ($stmt->execute([$new_status, $staff_id])) {
                header('Location: staff.php?success=status_changed');
                exit();
            } else {
                error_log("Failed to toggle status for user ID: $staff_id");
                header('Location: staff.php?error=status_failed');
                exit();
            }
        }
        // If $can_proceed was false, the script would have already exited with a redirect.

    } catch (PDOException $e) {
        error_log("Error toggling staff status: " . $e->getMessage());
        header('Location: staff.php?error=db_error'); // Consider adding a db_error case
        exit();
    }

} else {
    header('Location: staff.php');
    exit();
}
?>
