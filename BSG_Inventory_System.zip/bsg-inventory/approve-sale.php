<?php
// --- Role Check ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Redirect non-admins to the dashboard with an error message
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// --- Rest of the page code starts here ---
require_once 'config/database.php'; // If needed by this specific page
// require_once 'includes/header.php'; // This will be included AFTER the check if it's a display page

// --- Authorization Check ---
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php'); // Redirect unauthorized users
    exit();
}

$admin_user_id = $_SESSION['user_id'];

// --- Validate Request ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['sales_record_id']) || !is_numeric($_POST['sales_record_id'])) {
    header('Location: sales.php?error=invalid_request');
    exit();
}

$sales_record_id = (int)$_POST['sales_record_id'];

// --- Process Approval ---
$pdo->beginTransaction(); // Start Transaction

try {
    // 1. Fetch the sales record and verify it's 'pending'
    $stmt = $pdo->prepare("SELECT id, status FROM sales_records WHERE id = ? FOR UPDATE"); // Lock record
    $stmt->execute([$sales_record_id]);
    $sale_record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sale_record) {
        throw new Exception("Sale record not found.", 404);
    }
    if ($sale_record['status'] !== 'pending') {
        throw new Exception("Sale is not pending and cannot be approved.", 400);
    }

    // 2. Fetch sale items
    $itemStmt = $pdo->prepare("SELECT product_id, quantity_sold FROM sales_items WHERE sales_record_id = ?");
    $itemStmt->execute([$sales_record_id]);
    $sale_items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($sale_items)) {
         throw new Exception("Cannot approve sale with no items.", 400);
    }

    // 3. Check stock and prepare updates (within transaction)
    $product_updates = [];
    foreach ($sale_items as $item) {
        $prodStmt = $pdo->prepare("SELECT name, current_quantity FROM products WHERE id = ? FOR UPDATE"); // Lock product row
        $prodStmt->execute([$item['product_id']]);
        $product = $prodStmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
             throw new Exception("Product ID {$item['product_id']} not found during approval.", 404);
        }

        // CRITICAL STOCK CHECK
        if ($product['current_quantity'] < $item['quantity_sold']) {
            throw new Exception("Insufficient stock for product '{$product['name']}'. Available: {$product['current_quantity']}, Required: {$item['quantity_sold']}", 409); // 409 Conflict
        }

        $product_updates[] = [
            'id' => $item['product_id'],
            'quantity_to_deduct' => $item['quantity_sold']
        ];
    }

    // 4. Update Product Inventory
    $updateProdStmt = $pdo->prepare("UPDATE products SET current_quantity = current_quantity - ? WHERE id = ?");
    foreach ($product_updates as $update) {
        $updateProdStmt->execute([$update['quantity_to_deduct'], $update['id']]);
         if ($updateProdStmt->rowCount() === 0) {
            // Should not happen if FOR UPDATE worked, but good to check
            throw new Exception("Failed to update stock for product ID {$update['id']}.");
        }
    }

    // 5. Update Sales Record Status
    $updateSaleStmt = $pdo->prepare("
        UPDATE sales_records
        SET status = 'approved', approved_by_user_id = ?, approved_at = NOW()
        WHERE id = ? AND status = 'pending' -- Ensure status hasn't changed
    ");
    $updateSaleStmt->execute([$admin_user_id, $sales_record_id]);

    if ($updateSaleStmt->rowCount() === 0) {
         throw new Exception("Failed to update sale record status or status was already changed.", 409);
    }

    // 6. Commit Transaction
    $pdo->commit();

    header('Location: sales.php?success=approved');
    exit();

} catch (Exception $e) {
    $pdo->rollBack(); // Rollback on any error
    error_log("Error approving sale (ID: $sales_record_id): " . $e->getMessage());

    // Determine appropriate error message for redirect
    $error_code = 'approve_failed';
    if ($e->getCode() === 409) { // Stock conflict or status already changed
        $error_code = 'stock_error'; // Use a specific code for stock issues
         // Include product name in error message if possible
         if (strpos($e->getMessage(), 'Insufficient stock') !== false) {
             // Extract relevant part of the message if needed, or use a generic stock error
             $error_code = 'stock_error';
         }
    } elseif ($e->getCode() === 404) {
        $error_code = 'not_found';
    } elseif ($e->getCode() === 400) {
         $error_code = 'invalid_status';
    }


    header('Location: view-sale.php?id=' . $sales_record_id . '&error=' . $error_code . '&msg=' . urlencode(substr($e->getMessage(), 0, 100))); // Redirect back to detail view with error
    exit();
}
?>
