<?php
// 1. Include header (starts session, checks login, sets $user_name, $user_role)
require_once 'includes/header.php';
// Ensure DB connection is available if header didn't already include it
if (!isset($pdo)) {
    require_once 'config/database.php';
}

// --- Dashboard Data Fetching ---
$total_products = $total_suppliers = $low_stock_count = $recent_pending_sales_count = 0;
$recent_pending_sales_value = 0.00;
$sales_chart_labels = $sales_chart_data = $product_summary = [];
$fetch_error = null;
$low_stock_threshold = 10;

// Pagination variables for product summary
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 5; // Number of products per page
$offset = ($page - 1) * $per_page;

if (isset($pdo)) {
    try {
        // Total Products
        $total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        // Total Suppliers
        $total_suppliers = $pdo->query("SELECT COUNT(*) FROM suppliers")->fetchColumn();
        // Low Stock Items
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE current_quantity <= ?");
        $stmt->execute([$low_stock_threshold]);
        $low_stock_count = $stmt->fetchColumn();
        // Recent Pending Sales (Last 24h)
        $recent = $pdo->query(
            "SELECT COUNT(*) as count, SUM(total_amount) as value
             FROM sales_records
             WHERE status='pending' AND sale_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)"
        )->fetch(PDO::FETCH_ASSOC);
        $recent_pending_sales_count = $recent['count'] ?? 0;
        $recent_pending_sales_value = $recent['value'] ?? 0.00;

        // --- *** MODIFICATION START: Sales Chart Data (Value Last 7d) *** ---
        $raw_sales_value = $pdo->query(
            "SELECT DATE(approved_at) as day, SUM(total_amount) as total_value
             FROM sales_records
             WHERE status='approved' AND approved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(approved_at)
             ORDER BY day ASC"
        )->fetchAll(PDO::FETCH_ASSOC);

        $sales_value_by_day = [];
        $sales_chart_labels = []; // Reset labels here to ensure they match the loop

        for ($i = 6; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $sales_value_by_day[$d] = 0.00; // Initialize each day in the range to 0.00
            $sales_chart_labels[] = date('M d', strtotime($d)); // Build labels (e.g., 'Jan 01')
        }

        foreach ($raw_sales_value as $r) {
            if (isset($sales_value_by_day[$r['day']])) {
                // Use the summed total_value, cast to float
                $sales_value_by_day[$r['day']] = (float)$r['total_value'];
            }
        }
        $sales_chart_data = array_values($sales_value_by_day); // Get the final data array
        // --- *** MODIFICATION END: Sales Chart Data *** ---


        // Get total number of products for pagination
        $total_products_count = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        $total_pages = ceil($total_products_count / $per_page);

        // Modified product summary query with pagination (No changes needed here)
        $product_summary_query = "SELECT
                p.id,
                p.name,
                (p.current_quantity
                   - (SELECT COALESCE(SUM(se.quantity_added), 0)
                      FROM stock_entries se
                      WHERE se.product_id = p.id AND se.entry_date >= DATE_SUB(NOW(), INTERVAL 1 DAY))
                   + (SELECT COALESCE(SUM(si.quantity_sold), 0)
                      FROM sales_items si
                      JOIN sales_records sr ON si.sales_record_id = sr.id
                      WHERE si.product_id = p.id AND sr.status = 'approved' AND sr.approved_at >= DATE_SUB(NOW(), INTERVAL 1 DAY))
                ) AS quantity_before,

                (SELECT COALESCE(SUM(si.quantity_sold), 0)
                 FROM sales_items si
                 JOIN sales_records sr ON si.sales_record_id = sr.id
                 WHERE si.product_id = p.id AND sr.status = 'approved'
                ) AS total_quantity_sold,

                (SELECT COALESCE(SUM(se.quantity_added), 0)
                 FROM stock_entries se
                 WHERE se.product_id = p.id AND se.entry_date >= DATE_SUB(NOW(), INTERVAL 1 DAY)
                ) AS newly_added_quantity,

                p.current_quantity AS quantity_after
            FROM
                products p
            ORDER BY
                p.name
            LIMIT :limit OFFSET :offset";

        $stmt = $pdo->prepare($product_summary_query);
        $stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $product_summary = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log('Dashboard fetch error: ' . $e->getMessage());
        $fetch_error = 'Could not load dashboard data.';
    }
} else {
    $fetch_error = 'Database connection not available.';
}

// Helper function to generate pagination URL
function get_pagination_url($page) {
    $params = $_GET;
    $params['page'] = $page;
    return '?' . http_build_query($params);
}
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<div class="container px-4 py-6 mx-auto">
    <!-- Header -->
    <div class="mb-8">
<h1 class="mt-1 text-3xl font-semibold text-gray-800">Welcome, <?= htmlspecialchars(ucfirst($user_name)) ?>!</h1>
        <p class="mt-1 text-gray-600">Here's what's happening with your inventory today.</p>
    </div>

    <?php if ($fetch_error): ?>
        <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg"><?= htmlspecialchars($fetch_error) ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['error']) && $_GET['error'] === 'unauthorized'): ?>
        <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg">You do not have permission to access the requested page.</div>
    <?php endif; ?>

    <!-- Summary Statistics (No changes needed here) -->
    <div class="grid grid-cols-1 gap-6 mb-8 sm:grid-cols-2 lg:grid-cols-4">
        <!-- Total Products Card -->
        <div class="bg-white rounded-lg shadow">
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
                <a href="products.php" class="block p-6 transition hover:bg-gray-50">
            <?php else: ?>
                <div class="p-6">
            <?php endif; ?>
                <div class="flex items-center">
                    <div class="p-3 text-blue-500 bg-blue-100 rounded-full"><i class="fas fa-boxes fa-2x"></i></div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500 uppercase">Total Products</p>
                        <p class="text-2xl font-semibold text-gray-900"><?= $total_products ?></p>
                    </div>
                </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?></a><?php else: ?></div><?php endif; ?>
        </div>

        <!-- Total Suppliers Card -->
        <div class="bg-white rounded-lg shadow">
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
                <a href="suppliers.php" class="block p-6 transition hover:bg-gray-50">
            <?php else: ?>
                <div class="p-6">
            <?php endif; ?>
                <div class="flex items-center">
                    <div class="p-3 text-purple-500 bg-purple-100 rounded-full"><i class="fas fa-truck fa-2x"></i></div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500 uppercase">Total Suppliers</p>
                        <p class="text-2xl font-semibold text-gray-900"><?= $total_suppliers ?></p>
                    </div>
                </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?></a><?php else: ?></div><?php endif; ?>
        </div>

        <!-- Low Stock Items Card -->
        <div class="bg-white rounded-lg shadow">
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
                <a href="products.php" class="block p-6 transition hover:bg-gray-50">
            <?php else: ?>
                <div class="p-6">
            <?php endif; ?>
                <div class="flex items-center">
                    <div class="p-3 text-yellow-500 bg-yellow-100 rounded-full"><i class="fas fa-exclamation-triangle fa-2x"></i></div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500 uppercase">Low Stock Items</p>
                        <p class="text-2xl font-semibold text-gray-900"><?= $low_stock_count ?> <span class="text-xs">(<= <?= $low_stock_threshold ?> units)</span></p>
                    </div>
                </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?></a><?php else: ?></div><?php endif; ?>
        </div>

        <!-- Recent Pending Sales Card -->
        <div class="bg-white rounded-lg shadow">
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?>
                <a href="sales.php?status=pending" class="block p-6 transition hover:bg-gray-50">
            <?php else: ?>
                <div class="p-6">
            <?php endif; ?>
                <div class="flex items-center">
                    <div class="p-3 text-green-500 bg-green-100 rounded-full"><i class="fas fa-hourglass-half fa-2x"></i></div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500 uppercase">Pending Sales (24h)</p>
                        <p class="text-2xl font-semibold text-gray-900"><?= $recent_pending_sales_count ?> <span class="text-sm">(₱<?= number_format($recent_pending_sales_value, 2) ?>)</span></p>
                    </div>
                </div>
            <?php if ($user_role === 'admin' || $user_role === 'staff'): ?></a><?php else: ?></div><?php endif; ?>
        </div>
    </div>

    <!-- Product Inventory Summary Table (No changes needed here) -->
    <div class="mb-8 bg-white rounded-lg shadow">
        <h2 class="p-4 text-lg font-semibold text-gray-800 border-b">Product Inventory Summary</h2>
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                <thead class="text-xs text-white uppercase bg-[#0078b6]">
                    <tr>
                        <th class="px-6 py-3">ID</th>
                        <th class="px-6 py-3">Product Name</th>
                        <th class="px-6 py-3 text-center">Qty Before (24h)</th>
                        <th class="px-6 py-3 text-center">Total Qty Sold</th>
                        <th class="px-6 py-3 text-center">Newly Added Qty (24h)</th>
                        <th class="px-6 py-3 text-center">Qty After</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($product_summary)): ?>
                        <tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">No product data available.</td></tr>
                    <?php else: ?>
                        <?php foreach ($product_summary as $p): ?>
                            <tr class="border-b hover:bg-gray-50">
                                <td class="px-6 py-4"><?= htmlspecialchars($p['id']) ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"><?= htmlspecialchars($p['name']) ?></td>
                                <td class="px-6 py-4 text-center"><?= htmlspecialchars($p['quantity_before']) ?></td>
                                <td class="px-6 py-4 text-center"><?= htmlspecialchars($p['total_quantity_sold']) ?></td>
                                <td class="px-6 py-4 text-center"><?= htmlspecialchars($p['newly_added_quantity']) ?></td>
                                <td class="px-6 py-4 text-center"><?= htmlspecialchars($p['quantity_after']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination Controls (No changes needed here) -->
        <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-between px-6 py-4 border-t">
            <div class="text-sm text-gray-700">
                Showing <span class="font-medium"><?= ($offset + 1) ?></span> to
                <span class="font-medium"><?= min($offset + $per_page, $total_products_count) ?></span> of
                <span class="font-medium"><?= $total_products_count ?></span> products
            </div>
            <div class="flex space-x-1">
                <?php if ($page > 1): ?>
                    <a href="<?= get_pagination_url(1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-double-left"></i>
                    </a>
                    <a href="<?= get_pagination_url($page - 1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-left"></i>
                    </a>
                <?php endif; ?>

                <?php
                // Calculate range of page numbers to show
                $range = 2; // Show 2 pages before and after current
                $start_page = max(1, $page - $range);
                $end_page = min($total_pages, $page + $range);

                // Always show first page
                if ($start_page > 1) {
                    echo '<a href="' . get_pagination_url(1) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">1</a>';
                    if ($start_page > 2) {
                        echo '<span class="px-3 py-1 text-sm text-gray-700">...</span>';
                    }
                }

                // Show page numbers
                for ($i = $start_page; $i <= $end_page; $i++) {
                    if ($i == $page) {
                        echo '<span class="px-3 py-1 text-sm text-white bg-blue-600 border border-blue-600 rounded-md">' . $i . '</span>';
                    } else {
                        echo '<a href="' . get_pagination_url($i) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">' . $i . '</a>';
                    }
                }

                // Always show last page
                if ($end_page < $total_pages) {
                    if ($end_page < $total_pages - 1) {
                        echo '<span class="px-3 py-1 text-sm text-gray-700">...</span>';
                    }
                    echo '<a href="' . get_pagination_url($total_pages) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">' . $total_pages . '</a>';
                }
                ?>

                <?php if ($page < $total_pages): ?>
                    <a href="<?= get_pagination_url($page + 1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-right"></i>
                    </a>
                    <a href="<?= get_pagination_url($total_pages) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-double-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sales Trend Chart -->
    <div class="grid grid-cols-1 gap-6 mb-6">
        <div class="p-6 bg-white rounded-lg shadow">
            <h2 class="mb-4 text-lg font-semibold text-gray-800">Sales Trend (Last 7 Days)</h2>
            <div style="height:400px;"><canvas id="salesTrendChart"></canvas></div>
        </div>
    </div>
</div>

<!-- --- *** MODIFICATION START: Chart.js Configuration *** --- -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('salesTrendChart');
    if (ctx) {
        // Helper function to format currency for PHP
        const formatPHP = (value) => {
            return new Intl.NumberFormat('en-PH', {
                style: 'currency',
                currency: 'PHP'
            }).format(value);
        };

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($sales_chart_labels) ?>,
                datasets: [{
                    label: 'Total Sales Value (PHP)', // Updated Label
                    data: <?= json_encode($sales_chart_data) ?>, // Use the new sales value data
                    borderColor: 'rgb(65, 105, 225)', // Royal Blue
                    backgroundColor: 'rgba(65, 105, 225, 0.2)',
                    tension: 0.1,
                    borderWidth: 2,
                    fill: true
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            // Format Y-axis ticks as currency
                            callback: function(value, index, ticks) {
                                return '₱' + new Intl.NumberFormat('en-US').format(value); // Simple PHP formatting for axis
                            }
                        }
                    }
                },
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            // Format tooltip label as currency
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed.y !== null) {
                                    label += formatPHP(context.parsed.y); // Use the PHP formatting function
                                }
                                return label;
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>
<!-- --- *** MODIFICATION END: Chart.js Configuration *** --- -->

<?php require_once 'includes/footer.php'; ?>
