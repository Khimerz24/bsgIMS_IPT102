<?php

// --- Core includes, session and login check (before any output) ---
require_once 'config/database.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];

// --- Handle Sale Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cart_items = isset($_POST['cart_items']) ? json_decode($_POST['cart_items'], true) : [];
    if (empty($cart_items)) {
        $errors['general'] = "Cannot record an empty sale. Please add products.";
    } // --- Inside the if ($_SERVER['REQUEST_METHOD'] === 'POST') block ---
// ... after checking if $cart_items is empty ...
    else {
        $pdo->beginTransaction(); // START TRANSACTION
        try {
            // --- Common logic: Validate stock and prepare items ---
            $total_sale_amount = 0;
            $items_to_insert = [];
            $product_updates = []; // Store necessary stock updates

            foreach ($cart_items as $item) {
                // Basic validation of cart item structure
                if (!isset($item['id'], $item['quantity']) || !is_numeric($item['quantity']) || $item['quantity'] <= 0) {
                    throw new Exception("Invalid cart data received.");
                }

                // Fetch product details and lock the row for update
                $prodStmt = $pdo->prepare("SELECT id, name, unit_price, current_quantity FROM products WHERE id = ? FOR UPDATE");
                $prodStmt->execute([(int)$item['id']]);
                $product = $prodStmt->fetch(PDO::FETCH_ASSOC);

                if (!$product) {
                    // Should ideally not happen if products are fetched correctly for the form
                    throw new Exception("Product ID {$item['id']} not found during sale recording.");
                }

                // Check stock availability
                if ($product['current_quantity'] < (int)$item['quantity']) {
                    // Add specific error for this item
                    $errors['stock_' . $product['id']] = "Insufficient stock for " . htmlspecialchars($product['name']) . ". Available: " . $product['current_quantity'];
                    // Continue checking other items, but we'll throw an error later if any stock issue exists
                    continue; // Skip adding this item to insert/update lists if stock is insufficient
                }

                // Prepare item for sales_items table
                $line_total = $item['quantity'] * $product['unit_price'];
                $total_sale_amount += $line_total;
                $items_to_insert[] = [
                    'product_id' => $item['id'],
                    'quantity_sold' => $item['quantity'],
                    'unit_price_at_sale' => $product['unit_price'],
                    'line_total' => $line_total
                ];

                // Prepare stock update info (will only be used if admin)
                $product_updates[] = [
                    'id' => $item['id'],
                    'quantity_to_deduct' => $item['quantity']
                ];
            } // End foreach loop

            // If any stock errors were found during the loop, stop the process
            if (!empty($errors)) {
                throw new Exception("Stock validation failed.");
            }
            // --- End common logic ---


            // --- Role-Specific Logic ---
            $user_role = $_SESSION['role']; // Get current user's role
            $final_status = '';
            $approved_by = null;
            $approved_at_sql = 'NULL'; // SQL NULL value
            $sql_params = [];
            $success_message_code = '';

            if ($user_role === 'admin') {
                // Admin: Directly approve
                $final_status = 'approved';
                $approved_by = $user_id; // Admin approves their own sale
                $approved_at_sql = 'NOW()'; // Use SQL NOW() function
                $success_message_code = 'approved_direct'; // New success code

                // Prepare SQL for sales_records insert
                $sql = "INSERT INTO sales_records
                        (staff_user_id, total_amount, status, sale_date, approved_by_user_id, approved_at)
                        VALUES (?, ?, ?, NOW(), ?, $approved_at_sql)"; // Embed NOW() or NULL directly
                $sql_params = [$user_id, $total_sale_amount, $final_status, $approved_by];

            } else {
                // Staff: Set to pending
                $final_status = 'pending';
                $approved_by = null;
                $approved_at_sql = 'NULL';
                $success_message_code = 'recorded'; // Existing success code

                 // Prepare SQL for sales_records insert
                $sql = "INSERT INTO sales_records
                        (staff_user_id, total_amount, status, sale_date, approved_by_user_id, approved_at)
                        VALUES (?, ?, ?, NOW(), ?, $approved_at_sql)"; // Embed NOW() or NULL directly
                $sql_params = [$user_id, $total_sale_amount, $final_status, $approved_by];
            }
            // --- End Role-Specific Logic ---


            // --- Database Operations ---

            // 1. Insert into sales_records
            $stmt = $pdo->prepare($sql);
            $stmt->execute($sql_params);
            $sales_id = $pdo->lastInsertId();

            // 2. Insert into sales_items (always happens)
            $itemStmt = $pdo->prepare("INSERT INTO sales_items (sales_record_id, product_id, quantity_sold, unit_price_at_sale, line_total) VALUES (?, ?, ?, ?, ?)");
            foreach ($items_to_insert as $si) {
                $itemStmt->execute([$sales_id, $si['product_id'], $si['quantity_sold'], $si['unit_price_at_sale'], $si['line_total']]);
            }

            // 3. Update product stock *ONLY IF ADMIN*
            if ($user_role === 'admin') {
                $updateProdStmt = $pdo->prepare("UPDATE products SET current_quantity = current_quantity - ? WHERE id = ?");
                foreach ($product_updates as $update) {
                    $updateProdStmt->execute([$update['quantity_to_deduct'], $update['id']]);
                    if ($updateProdStmt->rowCount() === 0) {
                        // This check is important, especially with FOR UPDATE, but good redundancy
                        throw new Exception("Failed to update stock for product ID {$update['id']} during admin sale recording.");
                    }
                }
            }

            // --- Commit Transaction ---
            $pdo->commit();

            // --- Redirect on Success ---
            header('Location: sales.php?success=' . $success_message_code);
            exit();

        } catch (Exception $e) {
            $pdo->rollBack(); // Rollback on ANY error
            error_log("Error recording sale: " . $e->getMessage());

            // Set appropriate error message
            if (strpos($e->getMessage(), 'Stock validation failed') !== false) {
                 $errors['general'] = 'Failed to record sale due to stock issues listed below.';
                 // Keep the specific stock errors in $errors array
            } elseif (strpos($e->getMessage(), 'Product ID') !== false && strpos($e->getMessage(), 'not found') !== false) {
                 $errors['general'] = 'Failed to record sale. One or more products could not be found.';
            } else {
                 $errors['general'] = 'Failed to record sale. An unexpected error occurred.';
            }
            // Let execution continue to display the form with errors
        }
    } // End else block (cart not empty)
}


// --- Prepare Products List ---
$available_products = [];
$fetch_error = null;
try {
    $stmt = $pdo->query("SELECT id, name, current_quantity, unit_price FROM products WHERE current_quantity > 0 ORDER BY name ASC");
    $available_products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching products: " . $e->getMessage());
    $fetch_error = "Could not retrieve product list.";
}

// --- Include Header ---
require_once 'includes/header.php';
?>

<div x-data="salesForm()" class="p-6">
  <div class="mx-auto space-y-6 max-w-7xl">

    <?php if (!empty($errors['general'])): ?>
      <div class="px-4 py-3 text-red-700 bg-red-100 border border-red-400 rounded-lg">
        <?= htmlspecialchars($errors['general']); ?>
      </div>
    <?php endif; ?>
    <?php if ($fetch_error): ?>
      <div class="px-4 py-3 text-yellow-700 bg-yellow-100 border border-yellow-400 rounded-lg">
        <?= htmlspecialchars($fetch_error); ?>
      </div>
    <?php endif; ?>

    <h1 class="text-3xl font-bold text-gray-800"></h1>

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

      <!-- Available Products Card -->
      <div class="bg-white rounded-lg shadow-lg lg:col-span-2">
        <div class="p-4 rounded-t-lg bg-primary-light">
          <h2 class="text-2xl font-bold text-gray-800">Available Products</h2>
        </div>
        <div class="p-6 space-y-4 rounded-b-lg bg-gray-50">
          <input type="text" x-model="searchTerm" placeholder="Search products..." 
                 class="w-full px-4 py-2 text-lg border-2 border-gray-300 rounded-lg shadow focus:ring focus:ring-primary focus:ring-opacity-50">
          <div class="overflow-y-auto border-2 border-gray-200 rounded-lg max-h-96">
            <table class="w-full text-sm text-left text-gray-600">
              <thead class="text-xs text-gray-700 uppercase bg-gray-100">
                <tr>
                  <th class="px-4 py-2">Product</th>
                  <th class="px-4 py-2 text-right">Price</th>
                  <th class="px-4 py-2 text-right">Stock</th>
                  <th class="px-4 py-2 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                <template x-for="product in filteredProducts" :key="product.id">
                  <tr class="border-b hover:bg-gray-50">
                    <td class="px-4 py-2" x-text="product.name"></td>
                    <td class="px-4 py-2 text-right" x-text="formatCurrency(product.unit_price)"></td>
                    <td class="px-4 py-2 text-right" x-text="product.current_quantity"></td>
                    <td class="px-4 py-2 text-center">
                                        <button @click="addToCart(product)"
                          class="px-2 py-1 text-sm text-white bg-blue-600 rounded hover:bg-blue-700 disabled:opacity-50"
                          :disabled="product.current_quantity <= 0">
                    Add
                  </button>

                    </td>
                  </tr>
                </template>
                <template x-if="filteredProducts.length === 0">
                  <tr><td colspan="4" class="px-4 py-4 text-center text-gray-500">No products found.</td></tr>
                </template>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Current Sale Card -->
      <div class="bg-white rounded-lg shadow-lg">
        <div class="p-4 rounded-t-lg bg-primary-light">
          <h2 class="text-2xl font-bold text-gray-800">Current Sale/s</h2>
        </div>
        <form method="POST" action="add-sale.php" id="sale-form" 
              class="p-6 space-y-4 rounded-b-lg bg-gray-50">
          <input type="hidden" name="cart_items" :value="JSON.stringify(cart)">
          <div class="space-y-3 overflow-y-auto max-h-80">
            <template x-for="(item,index) in cart" :key="item.id">
              <div class="flex items-center justify-between p-3 border-2 border-gray-200 rounded-lg">
                <div>
                  <p class="text-lg font-medium" x-text="item.name"></p>
                  <p class="text-sm text-gray-600" x-text="formatCurrency(item.unit_price) + ' x ' + item.quantity"></p>
                </div>
                <div class="flex items-center gap-2">
                  <input type="number" x-model.number="item.quantity" 
                         @change="updateQuantity(index, $event.target.value)" 
                         min="1" :max="item.max_quantity" 
                         class="w-16 px-2 py-1 text-sm text-right border-2 border-gray-300 rounded-lg">
                  <button type="button" @click="removeFromCart(index)" 
                          class="text-xl text-red-500 hover:text-red-700">
                    &times;
                  </button>
                </div>
              </div>
            </template>
            <template x-if="cart.length === 0">
              <p class="py-4 text-center text-gray-500">No items added yet.</p>
            </template>
          </div>
          <div class="pt-4 border-t-2 border-gray-200">
            <div class="flex justify-between text-xl font-semibold">
              <span>Total:</span>
              <span x-text="formatCurrency(totalAmount)"></span>
            </div>
            <button type="submit" 
                    class="w-full px-4 py-2 mt-4 text-lg font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 disabled:opacity-50" 
                    :disabled="cart.length === 0">
              Record Sales
            </button>
            <a href="sales.php" 
               class="block w-full px-4 py-2 mt-2 text-center text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">
              Cancel
            </a>
          </div>
        </form>
      </div>

    </div>
  </div>
</div>

<script>
  const allProducts = <?= json_encode($available_products) ?>;
  const errorsJs = <?= !empty($errors) ? json_encode($errors) : '{}' ?>;
  function salesForm() {
    return {
      searchTerm: '',
      products: allProducts.map(p => ({ ...p, unit_price: parseFloat(p.unit_price), current_quantity: parseInt(p.current_quantity) })),
      cart: [],
      errorsJs,
      get filteredProducts() {
        return this.searchTerm ? this.products.filter(p => p.name.toLowerCase().includes(this.searchTerm.toLowerCase())) : this.products;
      },
      get totalAmount() { return this.cart.reduce((sum, i) => sum + i.quantity * i.unit_price, 0); },
      formatCurrency(a) { const n = parseFloat(a); return isNaN(n) ? '₱0.00' : '₱' + n.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,' ); },
      isProductInCart(id) { return this.cart.some(i => i.id === id); },
          addToCart(p) {
          if (p.current_quantity <= 0) {
              // Silently prevent adding out-of-stock items
              console.warn(`${p.name} is out of stock.`);
              return;
          }

          const existingCartIndex = this.cart.findIndex(item => item.id === p.id);

          if (existingCartIndex !== -1) {
              // Product is already in the cart, increment quantity if possible
              const item = this.cart[existingCartIndex];
              if (item.quantity < item.max_quantity) {
                  item.quantity++; // Increment quantity
              } else {
                  // Optional: Notify user they reached the max stock limit (e.g., using a temporary message)
                  console.warn(`Max stock (${item.max_quantity}) reached for ${item.name}.`);
                  // alert(`You cannot add more ${item.name}. Maximum stock (${item.max_quantity}) reached.`); // Avoid alerts if possible
              }
          } else {
              // Product is not in the cart, add it with quantity 1
              this.cart.push({
                  id: p.id,
                  name: p.name,
                  quantity: 1, // Start with quantity 1
                  unit_price: p.unit_price,
                  max_quantity: p.current_quantity // Store max available stock
              });
          }
      },

      updateQuantity(i,q) { const item=this.cart[i]; const qty=parseInt(q)||1; if(qty<1) return item.quantity=1; if(qty>item.max_quantity) return item.quantity=item.max_quantity;
          item.quantity=qty; },
      removeFromCart(i) { this.cart.splice(i,1); }
    }
  }
</script>

<?php require_once 'includes/footer.php'; ?>
