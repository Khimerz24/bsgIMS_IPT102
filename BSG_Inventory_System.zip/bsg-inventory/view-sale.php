<?php
require_once 'includes/header.php'; // Session started, user logged in
require_once 'config/database.php';

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// --- Get Sale ID and Fetch Data ---
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: sales.php?error=not_found');
    exit();
}
$sales_record_id = (int)$_GET['id'];

try {
    // Fetch main sale record details
    $stmt = $pdo->prepare("
        SELECT sr.*, u_staff.username as staff_name, u_admin.username as admin_name
        FROM sales_records sr
        JOIN users u_staff ON sr.staff_user_id = u_staff.id
        LEFT JOIN users u_admin ON sr.approved_by_user_id = u_admin.id
        WHERE sr.id = ?
    ");
    $stmt->execute([$sales_record_id]);
    $sale_record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sale_record) {
        header('Location: sales.php?error=not_found');
        exit();
    }

    // --- Authorization: Staff can only view their own records ---
    if ($user_role === 'staff' && $sale_record['staff_user_id'] !== $user_id) {
         header('Location: sales.php?error=unauthorized'); // Or a more specific error
         exit();
    }

    // Fetch sale items
    $itemStmt = $pdo->prepare("
        SELECT si.*, p.name as product_name
        FROM sales_items si
        JOIN products p ON si.product_id = p.id
        WHERE si.sales_record_id = ?
    ");
    $itemStmt->execute([$sales_record_id]);
    $sale_items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching sale details (ID: $sales_record_id): " . $e->getMessage());
    header('Location: sales.php?error=db_error');
    exit();
}

 // --- Helper Function for Status Badge ---
function getStatusBadgeClass($status) {
    return match ($status) {
        'approved' => 'bg-green-100 text-green-800',
        'rejected' => 'bg-red-100 text-red-800',
        'pending' => 'bg-yellow-100 text-yellow-800',
        default => 'bg-gray-100 text-gray-800',
    };
}
?>

<div class="container px-4 py-6 mx-auto">
    <div class="max-w-4xl p-6 mx-auto bg-white rounded-lg shadow">

        <!-- Header Section -->
        <div class="flex flex-col items-start justify-between pb-4 mb-6 border-b sm:flex-row sm:items-center">
            <div>
                <h1 class="text-2xl font-semibold text-gray-800">Sale Details - ID: <?= htmlspecialchars($sale_record['id']) ?></h1>
                <p class="text-sm text-gray-500">Recorded on: <?= date('M d, Y H:i', strtotime($sale_record['sale_date'])) ?> by <?= htmlspecialchars($sale_record['staff_name']) ?></p>
            </div>
            <span class="mt-2 sm:mt-0 px-3 py-1 rounded-full text-sm font-medium <?= getStatusBadgeClass($sale_record['status']) ?>">
                <?= ucfirst($sale_record['status']) ?>
            </span>
        </div>

         <!-- Approval/Rejection Info -->
         <?php if ($sale_record['status'] !== 'pending'): ?>
         <div class="p-4 mb-6 border border-gray-200 rounded bg-gray-50">
             <h3 class="mb-2 font-semibold text-gray-700">Processing Information</h3>
             <p class="text-sm">Status: <span class="font-medium"><?= ucfirst($sale_record['status']) ?></span></p>
             <p class="text-sm">Processed By: <span class="font-medium"><?= htmlspecialchars($sale_record['admin_name'] ?? 'N/A') ?></span></p>
             <p class="text-sm">Processed At: <span class="font-medium"><?= $sale_record['approved_at'] ? date('M d, Y H:i', strtotime($sale_record['approved_at'])) : 'N/A' ?></span></p>
             <?php if ($sale_record['status'] === 'rejected' && !empty($sale_record['rejection_reason'])): ?>
                 <p class="mt-2 text-sm">Reason for Rejection:</p>
                 <p class="p-2 text-sm text-red-700 border border-red-200 rounded bg-red-50"><?= nl2br(htmlspecialchars($sale_record['rejection_reason'])) ?></p>
             <?php endif; ?>
         </div>
         <?php endif; ?>


        <!-- Items Sold -->
        <div class="mb-6">
            <h2 class="mb-3 text-lg font-semibold text-gray-800">Items Sold</h2>
            <div class="overflow-x-auto border rounded">
                 <table class="w-full text-sm text-left text-gray-600">
                    <thead class="text-xs uppercase table-header">
                        <tr>
                            <th class="px-4 py-2">Product</th>
                            <th class="px-4 py-2 text-right">Quantity</th>
                            <th class="px-4 py-2 text-right">Unit Price (at sale)</th>
                            <th class="px-4 py-2 text-right">Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($sale_items as $item): ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?= htmlspecialchars($item['product_name']) ?></td>
                            <td class="px-4 py-2 text-right"><?= htmlspecialchars($item['quantity_sold']) ?></td>
                            <td class="px-4 py-2 text-right">₱<?= number_format($item['unit_price_at_sale'], 2) ?></td>
                            <td class="px-4 py-2 text-right">₱<?= number_format($item['line_total'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="font-semibold bg-gray-50">
                        <tr>
                            <td colspan="3" class="px-4 py-2 text-right">Total Amount:</td>
                            <td class="px-4 py-2 text-right">₱<?= number_format($sale_record['total_amount'], 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

        <!-- Admin Actions (Only if Admin and Pending) -->
        <?php if ($user_role === 'admin' && $sale_record['status'] === 'pending'): ?>
        <div class="pt-6 mt-6 border-t">
             <h2 class="mb-4 text-lg font-semibold text-gray-800">Admin Actions</h2>
             <div class="flex flex-col gap-4 md:flex-row">
                 <!-- Approval Form -->
                 <form method="POST" action="approve-sale.php" onsubmit="return confirm('Are you sure you want to APPROVE this sale? Inventory will be updated.');" class="flex-1">
                     <input type="hidden" name="sales_record_id" value="<?= $sales_record_id ?>">
                     <button type="submit" class="w-full px-4 py-2 text-white transition bg-green-600 rounded-md hover:bg-green-700">
                         <i class="mr-2 fas fa-check"></i>Approve Sale
                     </button>
                 </form>

                 <!-- Rejection Form -->
                 <form method="POST" action="reject-sale.php" onsubmit="return confirm('Are you sure you want to REJECT this sale?');" class="flex-1">
                     <input type="hidden" name="sales_record_id" value="<?= $sales_record_id ?>">
                     <div class="mb-2">
                         <label for="rejection_reason" class="block mb-1 text-sm font-medium text-gray-700">Reason for Rejection (Optional)</label>
                         <textarea name="rejection_reason" id="rejection_reason" rows="2" class="w-full p-2 border rounded-md shadow-sm focus:border-red-500 focus:ring-red-500"></textarea>
                     </div>
                     <button type="submit" class="w-full px-4 py-2 text-white transition bg-red-600 rounded-md hover:bg-red-700">
                          <i class="mr-2 fas fa-times"></i>Reject Sale
                     </button>
                 </form>
             </div>
        </div>
        <?php endif; ?>

         <!-- Back Button -->
         <div class="mt-6 text-center">
             <a href="sales.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">
                 <i class="mr-2 fas fa-arrow-left"></i>Back to Sales List
             </a>
         </div>

    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
