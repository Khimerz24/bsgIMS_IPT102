<?php
require_once 'config/database.php';

// Test password hash
$test_password = 'admin123';
$hash = password_hash($test_password, PASSWORD_DEFAULT);
echo "Generated hash for 'admin123': " . $hash . "\n\n";

// Check if user exists
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute(['admin']);
$user = $stmt->fetch();

echo "User found: " . ($user ? "Yes" : "No") . "\n";
if ($user) {
    echo "Stored password hash: " . $user['password'] . "\n";
    echo "Password verification result: " . (password_verify('admin123', $user['password']) ? "Success" : "Failed") . "\n";
}