<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) { // Only check if logged in
    header('Location: login.php'); // Redirect to login if not logged in
    exit();
}

require_once 'config/database.php';
require_once 'includes/header.php';

try {
    $catStmt = $pdo->query("SELECT id, name FROM categories ORDER BY name");
    $categories = $catStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error fetching categories: " . $e->getMessage());
    $categories = [];
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_id = isset($_GET['category']) ? trim($_GET['category']) : '';

// Pagination variables
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 12; // Number of products per page
$offset = ($page - 1) * $per_page;

// Base query for products with filters
$query = "SELECT p.*, c.name as category_name, s.name as supplier_name
          FROM products p
          LEFT JOIN categories c ON p.category_id = c.id
          LEFT JOIN suppliers s ON p.supplier_id = s.id
          WHERE p.status = 'active'";

$params = [];

if ($search) {
    $query .= " AND (p.name LIKE :search OR p.id LIKE :search_id)";    
    $params[':search'] = "%$search%";
    $params[':search_id'] = $search;
}
if ($category_id && is_numeric($category_id)) {
    $query .= " AND p.category_id = :category_id";    
    $params[':category_id'] = $category_id;
}

// Count total matching products (for pagination)
$count_query = str_replace("p.*, c.name as category_name, s.name as supplier_name", "COUNT(*) as total", $query);
try {
    $count_stmt = $pdo->prepare($count_query);
    $count_stmt->execute($params);
    $total_products = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $total_pages = ceil($total_products / $per_page);
} catch (PDOException $e) {
    error_log("Error counting products: " . $e->getMessage());
    $total_products = 0;
    $total_pages = 1;
}

// Add sorting and pagination placeholders to query
$query .= " ORDER BY p.name ASC LIMIT :per_page OFFSET :offset";

// Prepare the statement
$stmt = $pdo->prepare($query);

// Bind the filter parameters (if any) - these are usually fine with execute array
$filter_params = [];
if ($search) {
    $filter_params[':search'] = "%$search%";
    $filter_params[':search_id'] = $search;
}
if ($category_id && is_numeric($category_id)) {
    $filter_params[':category_id'] = $category_id;
}

// Explicitly bind LIMIT and OFFSET parameters as integers
$stmt->bindParam(':per_page', $per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);

// Bind the filter parameters using bindValue (safer for loops/dynamic params)
foreach ($filter_params as $key => &$val) {
    // Determine type if necessary, but PDO often handles strings well here
    $stmt->bindValue($key, $val);
}
// It's good practice to unset the reference variable after the loop
unset($val);


try {
    // Execute the statement (no array passed here as params are bound)
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Error fetching products: " . $e->getMessage());
    $fetch_error = "Could not retrieve product data.";
    $products = [];
}


function getProductStatusClass($currentQty, $minQty) {
    $minQty = $minQty ?? 5;

    if ($currentQty <= 0) {
        return [
            'class' => 'bg-red-100 text-red-800 border border-red-200',
            'text' => 'Out of Stock'
        ];
    } elseif ($currentQty <= $minQty) {
        return [
            'class' => 'bg-yellow-100 text-yellow-800 border border-yellow-200',
            'text' => 'Low Stock'
        ];
    } else {
        return [
            'class' => 'bg-green-100 text-green-800 border border-green-200',
            'text' => 'In Stock'
        ];
    }
}

// Helper function to generate pagination URL
function get_pagination_url($page) {
    $params = $_GET;
    $params['page'] = $page;
    return '?' . http_build_query($params);
}
?>

<div class="container px-6 py-8 mx-auto">
    <?php if (isset($_GET['success'])): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['success']) {
                'added' => 'Product added successfully.',
                'updated' => 'Product updated successfully.',
                'stock_added' => 'Stock added successfully.',
                'deleted' => 'Product deleted successfully.',
                default => 'Operation successful.'
            }) ?>
            <?php if (isset($_GET['prod_id'])): ?>
                <a href="edit-product.php?id=<?= htmlspecialchars($_GET['prod_id']) ?>" class="ml-2 font-semibold underline hover:text-green-900">View/Edit Product</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
            <?= htmlspecialchars(match($_GET['error']) {
                'not_found' => 'Product not found.',
                'delete_failed' => 'Failed to delete product.',
                'update_failed' => 'Failed to update product.',
                'add_failed' => 'Failed to add product.',
                'invalid_request' => 'Invalid request.',
                'product-not-found' => 'Product not found.',
                'constraint' => 'Cannot delete product because it is referenced by other records.',
                'delete-failed' => 'Failed to delete product. Please try again.',
                default => 'An error occurred.'
            }) ?>
        </div>
    <?php endif; ?>
    <?php if (isset($fetch_error)): ?>
        <div class="p-4 mb-4 text-sm text-yellow-700 bg-yellow-100 rounded-lg" role="alert">
            <?= htmlspecialchars($fetch_error) ?>
        </div>
    <?php endif; ?>

    <div class="p-4 mb-6 bg-white rounded-lg shadow">
        <form method="GET" action="products.php" class="flex flex-wrap items-end gap-4">
            <div class="flex-grow">
                <label for="search" class="block mb-1 text-sm font-medium text-gray-700">Search</label>
                <div class="relative">
                    <input type="text" id="search" name="search" value="<?= htmlspecialchars($search) ?>"
                        class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Search by Name or ID">
                    <button type="submit" class="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-600 hover:text-blue-600 transition-colors">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>

            <div class="flex-grow">
                <label for="category" class="block mb-1 text-sm font-medium text-gray-700">Category</label>
                <select id="category" name="category"
                        class="w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($category_id == $cat['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="px-4 py-2 text-sm text-white transition duration-150 ease-in-out bg-blue-600 rounded-md hover:bg-blue-700">
                <i class="mr-1 fas fa-filter"></i> Filter
            </button>

            <a href="products.php" class="px-4 py-2 text-sm text-gray-700 transition-colors bg-gray-200 rounded-md hover:bg-gray-300">
                <i class="mr-1 fas fa-sync"></i> Reset
            </a>

            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="add-stock.php" class="px-4 py-2 ml-auto text-sm text-white transition duration-150 ease-in-out bg-green-600 rounded-md hover:bg-green-700">
                    <i class="mr-2 fas fa-plus-circle"></i>Add Stock
                </a>
                <a href="add-product.php" class="px-4 py-2 text-sm font-medium text-white transition duration-150 ease-in-out bg-blue-600 rounded-md hover:bg-blue-700">
                    <i class="mr-2 fas fa-plus"></i>Add Product
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="overflow-hidden bg-white rounded-lg shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-600">
                <thead class="text-xs text-white uppercase bg-[#0078b6]">
                    <tr>
                        <th scope="col" class="px-6 py-3 font-semibold">ID</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Name</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Category</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-right">Price</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Quantity</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Min Qty</th>
                        <th scope="col" class="px-6 py-3 font-semibold">Supplier</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Status</th>
                        <th scope="col" class="px-6 py-3 font-semibold text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="9" class="px-6 py-4 text-center text-gray-500">No products found matching your criteria.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                            <?php
                            $min_qty = $product['min_quantity'] ?? $product['reorder_level'] ?? 5;
                            $status = getProductStatusClass($product['current_quantity'], $min_qty);
                            ?>
                            <tr class="transition-colors bg-white border-b hover:bg-gray-50">
                                <td class="px-6 py-4 font-medium"><?= htmlspecialchars($product['id']) ?></td>
                                <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap"><?= htmlspecialchars($product['name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($product['category_name'] ?? 'N/A') ?></td>
                                <td class="px-6 py-4 font-medium text-right">₱<?= number_format($product['unit_price'], 2) ?></td>
                                <td class="px-6 py-4 text-center font-medium <?= ($product['current_quantity'] <= $min_qty) ? 'text-red-600' : '' ?>">
                                    <?= htmlspecialchars($product['current_quantity']) ?>
                                </td>
                                <td class="px-6 py-4 text-center text-gray-600">
                                    <?= htmlspecialchars($min_qty) ?>
                                </td>
                                <td class="px-6 py-4"><?= htmlspecialchars($product['supplier_name'] ?? 'N/A') ?></td>
                                <td class="px-6 py-4 text-center">
                                    <span class="px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap <?= $status['class'] ?>">
                                        <?= $status['text'] ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <div class="flex justify-center space-x-2">
                                        <a href="view-product.php?id=<?= $product['id'] ?>"
                                        class="p-1.5 text-blue-600 bg-blue-100 rounded-full hover:bg-blue-200 transition-colors" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if ($_SESSION['role'] === 'admin'): // Admin Only Actions ?>
                                            <a href="edit-product.php?id=<?= $product['id'] ?>"
                                            class="p-1.5 text-green-600 bg-green-100 rounded-full hover:bg-green-200 transition-colors" title="Edit Product">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form class="inline" method="POST" action="delete-product.php"
                                                onsubmit="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">
                                                <input type="hidden" name="id" value="<?= $product['id'] ?>">
                                                <button type="submit" class="p-1.5 text-red-600 bg-red-100 rounded-full hover:bg-red-200 transition-colors" title="Delete Product">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php endif; // End Admin Only Actions ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
        <div class="flex items-center justify-between px-6 py-4 border-t">
            <div class="text-sm text-gray-700">
                Showing <span class="font-medium"><?= ($offset + 1) ?></span> to 
                <span class="font-medium"><?= min($offset + $per_page, $total_products) ?></span> of 
                <span class="font-medium"><?= $total_products ?></span> products
            </div>
            <div class="flex space-x-1">
                <?php if ($page > 1): ?>
                    <a href="<?= get_pagination_url(1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-double-left"></i>
                    </a>
                    <a href="<?= get_pagination_url($page - 1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-left"></i>
                    </a>
                <?php endif; ?>
                
                <?php 
                // Calculate range of page numbers to show
                $range = 2; // Show 2 pages before and after current
                $start_page = max(1, $page - $range);
                $end_page = min($total_pages, $page + $range);
                
                // Always show first page
                if ($start_page > 1) {
                    echo '<a href="' . get_pagination_url(1) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">1</a>';
                    if ($start_page > 2) {
                        echo '<span class="px-3 py-1 text-sm text-gray-700">...</span>';
                    }
                }
                
                // Show page numbers
                for ($i = $start_page; $i <= $end_page; $i++) {
                    if ($i == $page) {
                        echo '<span class="px-3 py-1 text-sm text-white bg-blue-600 border border-blue-600 rounded-md">' . $i . '</span>';
                    } else {
                        echo '<a href="' . get_pagination_url($i) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">' . $i . '</a>';
                    }
                }
                
                // Always show last page
                if ($end_page < $total_pages) {
                    if ($end_page < $total_pages - 1) {
                        echo '<span class="px-3 py-1 text-sm text-gray-700">...</span>';
                    }
                    echo '<a href="' . get_pagination_url($total_pages) . '" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">' . $total_pages . '</a>';
                }
                ?>
                
                <?php if ($page < $total_pages): ?>
                    <a href="<?= get_pagination_url($page + 1) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-right"></i>
                    </a>
                    <a href="<?= get_pagination_url($total_pages) ?>" class="px-3 py-1 text-sm text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                        <i class="fas fa-angle-double-right"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>