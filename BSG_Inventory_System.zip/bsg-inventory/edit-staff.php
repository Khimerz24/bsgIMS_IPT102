<?php
// 1. Start Session and Check Role (BEFORE any other includes or output)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Role Check - This will EXIT if the user is not an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    error_log("Edit Staff Access Denied: Not logged in or not admin. Session UserID: " . ($_SESSION['user_id'] ?? 'N/A') . ", Role: " . ($_SESSION['role'] ?? 'N/A'));
    header('Location: dashboard.php?error=unauthorized');
    exit();
}

// 2. Include Database Config
require_once 'config/database.php';

// 3. Initialize Variables
$staff_id = null;
$username = '';
$role = '';
$status = '';
$errors = [];
$staff = null; // To hold fetched staff data

// 4. Get Staff ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    error_log("Edit Staff Error: Missing or invalid ID in GET request.");
    header('Location: staff.php?error=not_found');
    exit();
}
$staff_id = (int)$_GET['id'];
error_log("--- Edit Staff Page Load --- Staff ID from GET: " . $staff_id . " --- Session User ID: " . $_SESSION['user_id']);


// 5. Fetch Existing Staff Data (Do this BEFORE POST handling)
try {
    $stmt = $pdo->prepare("SELECT id, username, role, status FROM users WHERE id = ?");
    $stmt->execute([$staff_id]);
    $staff = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$staff) {
        error_log("Edit Staff Error: Staff member with ID $staff_id not found in database.");
        header('Location: staff.php?error=not_found');
        exit();
    }
    // Pre-populate variables with fetched data for initial form display
    $username = $staff['username'];
    $role = $staff['role'];
    $status = $staff['status'];
    error_log("Successfully fetched initial data for Staff ID: $staff_id. Role: $role, Status: $status");

} catch (PDOException $e) {
    error_log("Edit Staff DB Error (Initial Fetch): Staff ID $staff_id - " . $e->getMessage());
    // Set error, but let the page load to show it
    $errors['fetch'] = "Could not load staff data. Please check logs.";
    // We need header/footer, so don't exit yet. The form will show the error.
}


// 6. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("--- Edit Staff POST Request Received --- Staff ID: $staff_id --- Session User ID: " . $_SESSION['user_id']);

    // Ensure the ID from POST matches the ID from GET/URL
    if (!isset($_POST['id']) || (int)$_POST['id'] !== $staff_id) {
         error_log("Edit Staff POST Error: ID mismatch. GET ID: $staff_id, POST ID: " . ($_POST['id'] ?? 'N/A'));
         header('Location: staff.php?error=invalid_request');
         exit();
    }

    // Get submitted data (use fetched data as default if not submitted, e.g., disabled fields)
    $submitted_username = trim($_POST['username'] ?? $staff['username']); // Use original if not submitted
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    // For disabled fields, POST might not send them, rely on hidden inputs or original data
    $submitted_role = $_POST['role'] ?? $staff['role'];
    $submitted_status = $_POST['status'] ?? $staff['status'];

    error_log("POST Data Received - Username: $submitted_username, Role: $submitted_role, Status: $submitted_status, Password Provided: " . (!empty($password) ? 'Yes' : 'No'));


    // --- Validation ---
    $current_errors = []; // Use a temporary array for POST validation errors

    if (empty($submitted_username)) {
        $current_errors['username'] = 'Username is required.';
    } else {
        // Check if new username conflicts with OTHERS
        $stmtCheckUser = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmtCheckUser->execute([$submitted_username, $staff_id]);
        if ($stmtCheckUser->fetch()) {
            $current_errors['username'] = 'Username already taken by another user.';
        }
    }

    // Password validation (only if password fields are not empty)
    if (!empty($password)) {
         if (strlen($password) < 6) {
             $current_errors['password'] = 'Password must be at least 6 characters long.';
         } elseif ($password !== $confirm_password) {
            $current_errors['confirm_password'] = 'Passwords do not match.';
        }
    }

    if (!in_array($submitted_role, ['admin', 'staff'])) {
        $current_errors['role'] = 'Invalid role selected.';
    }
    if (!in_array($submitted_status, ['active', 'inactive'])) {
        $current_errors['status'] = 'Invalid status selected.';
    }

    // *** CRITICAL CHECK: Prevent self-deactivation/role change ***
    if ($staff_id === $_SESSION['user_id']) {
        error_log("SELF-EDIT DETECTED for Staff ID: $staff_id");

        // Check Status Change Attempt
        if ($submitted_status !== $staff['status']) { // Compare submitted status to original fetched status
             if ($submitted_status === 'inactive') {
                 error_log("Attempt to self-deactivate BLOCKED. Resetting status to '{$staff['status']}'.");
                 $current_errors['status'] = 'You cannot deactivate your own account.';
                 $submitted_status = $staff['status']; // Force status back to original
             } else {
                 // Allow reactivation if somehow they were inactive? Unlikely but safe.
                 error_log("Self-reactivation attempt allowed (or status didn't change to inactive). Submitted: $submitted_status, Original: {$staff['status']}");
             }
        } else {
             error_log("Self-edit: Status not changed from '{$staff['status']}'.");
        }

        // Check Role Change Attempt
        if ($submitted_role !== $staff['role']) { // Compare submitted role to original fetched role
            error_log("Attempt to change own role BLOCKED. Submitted: '$submitted_role', Original: '{$staff['role']}'. Resetting role.");
            $current_errors['role'] = 'You cannot change your own role.';
            $submitted_role = $staff['role']; // Force role back to original
        } else {
             error_log("Self-edit: Role not changed from '{$staff['role']}'.");
        }

    } else {
        error_log("Editing OTHER user (Staff ID: $staff_id). Self-edit checks skipped.");
    }

    // --- *** NEW CHECK: Prevent removing the last active admin *** ---
    // Check only if there are no existing validation errors from previous steps
     if (empty($current_errors)) {
         error_log("Validation passed (including last admin check) for Staff ID: $staff_id. Preparing database update.");
        if ($staff['role'] === 'admin' && ($submitted_role !== 'admin' || $submitted_status !== 'active')) {
            error_log("Potential last admin removal detected for Staff ID: $staff_id. Checking count...");
            try {
                $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active' AND id != ?");
                $stmtCount->execute([$staff_id]);
                $active_admin_count = $stmtCount->fetchColumn();

                error_log("Count of OTHER active admins: " . $active_admin_count);

                if ($active_admin_count === 0) {
                    error_log("ACTION BLOCKED: Cannot remove the last active admin (Staff ID: $staff_id).");
                    // Add a specific error message
                    $current_errors['general'] = 'Operation failed: Cannot remove the last active admin account.';
                    // Optionally, force the role/status back if they were changed (belt and suspenders)
                    $submitted_role = 'admin';
                    $submitted_status = 'active';
                } else {
                     error_log("Action allowed: Other active admins exist ($active_admin_count).");
                }
            } catch (PDOException $e) {
                error_log("Edit Staff DB Error (Last Admin Check): Staff ID $staff_id - " . $e->getMessage());
                $current_errors['general'] = 'Database error checking admin count. Operation aborted.';
            }
        } else {
             error_log("Last admin check skipped: Either not an admin or action doesn't remove admin status.");
        }
    }
     // If validation errors or DB error occurred, execution continues below to display the form again
}


// 7. Include Header (NOW it's safe to display HTML)
// Check if we need to redirect due to fetch error earlier but couldn't because header wasn't sent
if (isset($errors['fetch']) && !headers_sent()) {
     // This is unlikely to be reached if fetch fails, but as a safeguard
     error_log("Redirecting due to fetch error before header output.");
     header('Location: staff.php?error=fetch_failed'); // Or some other indicator
     exit();
}
require_once 'includes/header.php';

?>

<!-- 8. HTML Form Content -->
<div class="container px-4 py-6 mx-auto">
    <div class="max-w-2xl p-6 mx-auto bg-white rounded-lg shadow">
        <!-- Display Staff Name - Use fetched data -->
        <h1 class="mb-6 text-2xl font-semibold text-gray-800">Edit Staff Member: <?= htmlspecialchars($staff['username'] ?? '...') ?></h1>

        <?php if (!empty($errors['general'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['general']) ?>
            </div>
        <?php endif; ?>
         <?php if (!empty($errors['fetch'])): ?>
            <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
                <?= htmlspecialchars($errors['fetch']) ?>
            </div>
        <?php endif; ?>

        <!-- Ensure $staff_id is available for the action URL -->
        <form method="POST" action="edit-staff.php?id=<?= $staff_id ?>" class="space-y-4">
            <!-- Hidden ID for verification -->
            <input type="hidden" name="id" value="<?= $staff_id ?>">

            <!-- Username -->
            <div>
                <label for="username" class="block mb-1 text-sm font-medium text-gray-700">Username <span class="text-red-500">*</span></label>
                <!-- Value should reflect submitted data on error, or fetched data initially -->
                <input type="text" id="username" name="username" value="<?= htmlspecialchars($username) ?>" required
                       class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['username']) ? 'border-red-500' : 'border-gray-300' ?>">
                <?php if (isset($errors['username'])): ?>
                    <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['username']) ?></p>
                <?php endif; ?>
            </div>

            <!-- Password Change Section -->
             <div>
                <p class="mb-2 text-sm text-gray-600">Change Password (leave blank to keep current password)</p>
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                        <label for="password" class="block mb-1 text-sm font-medium text-gray-700">New Password</label>
                        <input type="password" id="password" name="password"
                               class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['password']) ? 'border-red-500' : 'border-gray-300' ?>">
                        <?php if (isset($errors['password'])): ?>
                            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['password']) ?></p>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label for="confirm_password" class="block mb-1 text-sm font-medium text-gray-700">Confirm New Password</label>
                        <input type="password" id="confirm_password" name="confirm_password"
                               class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['confirm_password']) ? 'border-red-500' : 'border-gray-300' ?>">
                        <?php if (isset($errors['confirm_password'])): ?>
                            <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['confirm_password']) ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Role and Status -->
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                    <label for="role" class="block mb-1 text-sm font-medium text-gray-700">Role <span class="text-red-500">*</span></label>
                    <!-- Check if editing self -->
                    <?php $is_self_edit = ($staff_id === $_SESSION['user_id']); ?>
                    <select id="role" name="role" required
                            class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['role']) ? 'border-red-500' : 'border-gray-300' ?> <?= $is_self_edit ? 'bg-gray-100 cursor-not-allowed' : '' ?>"
                            <?= $is_self_edit ? 'disabled title="Cannot change your own role"' : '' ?>>
                        <!-- Value should reflect submitted data on error, or fetched data initially -->
                        <option value="staff" <?= $role === 'staff' ? 'selected' : '' ?>>Staff</option>
                        <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                     <?php if (isset($errors['role'])): ?>
                        <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['role']) ?></p>
                    <?php endif; ?>
                     <?php if ($is_self_edit): ?>
                         <!-- Add a hidden input to submit the current role if the dropdown is disabled -->
                         <input type="hidden" name="role" value="<?= htmlspecialchars($staff['role']) ?>" /> <!-- Use original role -->
                         <p class="mt-1 text-xs text-gray-500">You cannot change your own role.</p>
                     <?php endif; ?>
                </div>
                 <div>
                    <label for="status" class="block mb-1 text-sm font-medium text-gray-700">Status <span class="text-red-500">*</span></label>
                    <select id="status" name="status" required
                            class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 <?= isset($errors['status']) ? 'border-red-500' : 'border-gray-300' ?> <?= $is_self_edit ? 'bg-gray-100 cursor-not-allowed' : '' ?>"
                            <?= $is_self_edit ? 'disabled title="Cannot change your own status"' : '' ?> >
                        <!-- Value should reflect submitted data on error, or fetched data initially -->
                        <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $status === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                     <?php if (isset($errors['status'])): ?>
                        <p class="mt-1 text-xs text-red-600"><?= htmlspecialchars($errors['status']) ?></p>
                    <?php endif; ?>
                     <?php if ($is_self_edit): ?>
                         <!-- Add a hidden input to submit the current status if the dropdown is disabled -->
                         <input type="hidden" name="status" value="<?= htmlspecialchars($staff['status']) ?>" /> <!-- Use original status -->
                         <p class="mt-1 text-xs text-gray-500">You cannot change your own status.</p>
                     <?php endif; ?>
                </div>
            </div>

            <!-- Buttons -->
            <div class="flex justify-end pt-4 space-x-3">
                <a href="staff.php" class="px-4 py-2 text-gray-700 transition bg-gray-200 rounded-md hover:bg-gray-300">Cancel</a>
                <button type="submit" class="px-4 py-2 text-white transition rounded-md bg-royal-blue hover:bg-primary-dark">
                    Update Staff Member
                </button>
            </div>
        </form>
    </div>
</div>

<?php
// 9. Include Footer
require_once 'includes/footer.php';
?>
